"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { getAnime } from "./anime";

/** Wrapper that fades/rises its content when it scrolls into view (anime.js). */
export function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    let played = false;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (e.isIntersecting && !played) {
            played = true;
            getAnime()
              .then(({ animate }) => {
                animate(el, {
                  opacity: [0, 1],
                  translateY: [26, 0],
                  duration: 850,
                  delay,
                  ease: "outCubic",
                });
              })
              .catch(() => {
                el.style.opacity = "1";
                el.style.transform = "none";
              });
            io.disconnect();
          }
        }
      },
      { threshold: 0.12 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [delay]);

  return (
    <div ref={ref} className={`will-animate ${className}`}>
      {children}
    </div>
  );
}

/** Full-entrance wrapper for screen switches (immediate, not scroll-based). */
export function FadeIn({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const t = setTimeout(() => {
      el.style.opacity = "1";
      el.style.transform = "none";
    }, 1400);
    getAnime()
      .then(({ animate }) => {
        animate(el, {
          opacity: [0, 1],
          translateY: [16, 0],
          duration: 550,
          ease: "outCubic",
        });
      })
      .catch(() => {
        el.style.opacity = "1";
        el.style.transform = "none";
      });
    return () => clearTimeout(t);
  }, []);

  return (
    <div ref={ref} className={`will-animate-rise ${className}`}>
      {children}
    </div>
  );
}

/** Number that counts up with an ease-out curve (dependency-free rAF). */
export function Counter({ value, className = "" }: { value: number; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const dur = 1100;
    const start = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = p === 1 ? 1 : 1 - Math.pow(2, -10 * p);
      el.textContent = String(Math.round(value * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value]);

  return (
    <span ref={ref} className={className}>
      0
    </span>
  );
}
