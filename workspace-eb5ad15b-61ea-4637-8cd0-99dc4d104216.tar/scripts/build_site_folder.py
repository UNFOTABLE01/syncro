#!/usr/bin/env python3
"""Build the multi-file UNFOTABLE site folder from the single-source parts.

Produces download/unfotable-site/ with:
  index.html    — markup, links to style.css / anime.min.js / app.js
  style.css     — full stylesheet (extracted from unfo_p1.html)
  app.js        — application logic (unfo_p2.js IIFE + unfo_p3.js injected)
  anime.min.js  — anime.js v4 UMD bundle copied from node_modules (offline-capable)
  README.md     — how to run / deploy / how IDs and the owner work
Also zips the folder to download/unfotable-site.zip.
"""
import pathlib
import shutil
import zipfile

ROOT = pathlib.Path("/home/z/my-project")
P1 = (ROOT / "scripts/unfo_p1.html").read_text(encoding="utf-8")
P2 = (ROOT / "scripts/unfo_p2.js").read_text(encoding="utf-8")
P3 = (ROOT / "scripts/unfo_p3.js").read_text(encoding="utf-8")
UMD = (ROOT / "node_modules/animejs/dist/bundles/anime.umd.min.js").read_text(encoding="utf-8")

DEST = ROOT / "download/unfotable-site"

# ---------- assertions on sources ----------
assert "/*__APP_B__*/" in P2, "p2 is missing the APP_B marker!"
assert "/*__ANIME_UMD__*/" in P1 and "/*__APP_A__*/" in P1, "p1 markers missing!"
assert "<style>" in P1 and "</style>" in P1, "p1 style block missing!"

# ---------- style.css ----------
style_start = P1.index("<style>") + len("<style>")
style_end = P1.index("</style>")
style_css = P1[style_start:style_end].strip() + "\n"
assert style_css.startswith(":root") and ".site-header" in style_css and "@keyframes" in style_css

# ---------- app.js ----------
app_js = P2.replace("/*__APP_B__*/", P3)
assert "function init()" in app_js and "OwnerView" in app_js and "async function seed()" in app_js

# ---------- index.html ----------
html = P1[:style_start] + P1[style_end:]                            # keep <style> tag -> "<style></style>"
html = html.replace(
    "<style></style>",
    '<link rel="stylesheet" href="style.css" />',
    1,
)
# The slice above keeps everything except the CSS text; now swap markers:
html = (
    html
    .replace(
        "<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&display=swap\" rel=\"stylesheet\" />",
        "<link href=\"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Source+Serif+4:opsz,wght@8..60,400;8..60,600;8..60,700&display=swap\" rel=\"stylesheet\" />\n"
        "<link rel=\"icon\" href=\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Crect width='64' height='64' rx='16' fill='%23000000'/%3E%3Ctext x='32' y='45' font-family='Georgia,serif' font-size='38' font-weight='600' fill='%23ffffff' text-anchor='middle'%3EU%3C/text%3E%3C/svg%3E\" />",
        1,
    )
    .replace("<style></style>", "", 1)
    .replace("<script>/*__ANIME_UMD__*/</script>", "<script src=\"anime.min.js\"></script>", 1)
    .replace("<script>/*__APP_A__*/</script>", "<script src=\"app.js\"></script>", 1)
    .replace("<script>/*__APP_B__*/</script>\n", "", 1)
    .replace("<script>/*__APP_B__*/</script>", "", 1)
)
assert "<style>" not in html, "inline style block still present!"
assert "__ANIME_UMD__" not in html and "__APP_A__" not in html and "__APP_B__" not in html
assert '<link rel="stylesheet" href="style.css" />' in html
assert '<script src="app.js"></script>' in html and '<script src="anime.min.js"></script>' in html
assert "UNFOTABLE" in html and "splid.unfo.workers.dev" in html

# ---------- write folder ----------
if DEST.exists():
    shutil.rmtree(DEST)
DEST.mkdir(parents=True)
(DEST / "index.html").write_text(html, encoding="utf-8")
(DEST / "style.css").write_text(style_css, encoding="utf-8")
(DEST / "app.js").write_text(app_js, encoding="utf-8")
(DEST / "anime.min.js").write_text(UMD, encoding="utf-8")

(DEST / "README.md").write_text("""# UNFOTABLE — standalone site (multi-file)

One ID. Many worlds. A self-contained static website hub — no server, no database.
All data (IDs, password hashes, websites, messages) lives in each visitor's browser
localStorage; nothing ever leaves their machine.

## Files

| File         | Purpose                                            |
|--------------|----------------------------------------------------|
| index.html   | Markup + loads everything below                    |
| style.css    | Full stylesheet (cream/black Anthropic-style theme)|
| app.js       | All application logic (views, auth, owner console) |
| anime.min.js | anime.js v4, stored locally — works offline        |

## Run it

- **Locally:** double-click `index.html`. That's it.
- **Host it:** upload the whole folder as-is to any static host —
  Netlify (drag & drop), Cloudflare Pages, GitHub Pages, Vercel, nginx…
  Keep the four files side by side.

## How IDs work

- Every ID is **free** — pick 8–24 letters/digits + a password, and it is yours.
- Nothing is pre-registered. The network ships with a single website:
  **Splid → https://splid.unfo.workers.dev/**
- The ID **Devanshu** (any letter case) automatically carries **full owner
  access**: see every ID, remove IDs, message any member, broadcast, curate
  the website grid, full portfolio.
- Each browser has its own member list — a fresh browser starts empty again.
  Clearing site data resets the network to its original state.

Rebuild from source: `python3 scripts/build_site_folder.py`
""", encoding="utf-8")

# ---------- zip ----------
ZIP = ROOT / "download/unfotable-site.zip"
if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(DEST.iterdir()):
        z.write(f, f"unfotable-site/{f.name}")

for f in sorted(DEST.iterdir()):
    print(f"  {f.name:<14} {f.stat().st_size/1024:8.1f} KB")
print(f"  zip           {ZIP.stat().st_size/1024:8.1f} KB")
print(f"OK -> {DEST}")
