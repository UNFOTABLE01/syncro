"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { Bell, Check, Fingerprint, Inbox, Loader2, MailOpen, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { getAnime, fmtAgo, fmtDate } from "./anime";
import { Reveal } from "./reveal";
import { SiteCard } from "./site-card";
import { useToast } from "@/hooks/use-toast";
import type { Me, Msg, Site } from "./types";

export function UserView({ me, sites, onRefreshSites }: { me: Me; sites: Site[]; onRefreshSites: () => void }) {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [unread, setUnread] = useState(0);
  const [loading, setLoading] = useState(true);
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [pwBusy, setPwBusy] = useState(false);
  const { toast } = useToast();
  const headRef = useRef<HTMLDivElement>(null);

  const loadInbox = useCallback(async () => {
    try {
      const res = await fetch("/api/messages");
      if (!res.ok) return;
      const data = await res.json();
      setMessages(data.messages ?? []);
      setUnread(data.unread ?? 0);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadInbox();
    const iv = setInterval(loadInbox, 20000); // live inbox
    return () => clearInterval(iv);
  }, [loadInbox]);

  useEffect(() => {
    const root = headRef.current;
    if (!root) return;
    getAnime()
      .then(({ animate, stagger }) => {
        animate(root.querySelectorAll(".dash-in"), {
          opacity: [0, 1],
          translateY: [20, 0],
          duration: 700,
          delay: stagger(90),
          ease: "outCubic",
        });
      })
      .catch(() => {
        root.querySelectorAll<HTMLElement>(".dash-in").forEach((el) => {
          el.style.opacity = "1";
          el.style.transform = "none";
        });
      });
  }, []);

  async function markRead(m: Msg) {
    if (m.read) return;
    setMessages((prev) => prev.map((x) => (x.id === m.id ? { ...x, read: true } : x)));
    setUnread((u) => Math.max(0, u - 1));
    await fetch(`/api/messages/${m.id}/read`, { method: "POST" });
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    setPwBusy(true);
    try {
      const res = await fetch("/api/auth/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: currentPw, newPassword: newPw }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Could not change password", description: data?.error, variant: "destructive" });
      } else {
        toast({ title: "Password updated", description: "Use the new one next time you sign in." });
        setCurrentPw("");
        setNewPw("");
      }
    } finally {
      setPwBusy(false);
    }
  }

  return (
    <main className="mx-auto w-full max-w-6xl flex-1 px-4 sm:px-6 pt-28 pb-20">
      <div ref={headRef}>
        <div className="dash-in flex flex-wrap items-center gap-2">
          <Badge className="rounded-full bg-primary px-3 py-1 text-[11px] font-semibold tracking-widest text-white">
            MEMBER
          </Badge>
          <Badge variant="secondary" className="rounded-full px-3 py-1 text-[11px] font-medium tracking-wide">
            Joined {fmtDate(me.createdAt)}
          </Badge>
        </div>
        <h1 className="dash-in mt-3 font-display text-4xl sm:text-5xl font-semibold tracking-tight">
          Welcome back, <span className="text-primary">{me.id}</span>
        </h1>
        <p className="dash-in mt-2 max-w-xl text-sm sm:text-base leading-relaxed text-muted-foreground">
          This is your corner of UNFOTABLE — messages from the owner land here, and the whole
          network is one click away.
        </p>
      </div>

      <div className="mt-10 grid gap-5 lg:grid-cols-5">
        {/* Inbox */}
        <Card className="dash-in lg:col-span-3 rounded-2xl border shadow-[0_1px_2px_rgba(31,30,26,0.04)]">
          <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
            <div className="flex items-center gap-2">
              <Inbox className="h-4 w-4 text-primary" />
              <CardTitle className="font-display text-xl">Inbox</CardTitle>
              {unread > 0 && (
                <Badge className="rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold text-white">
                  {unread} NEW
                </Badge>
              )}
            </div>
            <Button variant="ghost" size="sm" onClick={loadInbox} aria-label="Refresh inbox" className="h-8 w-8 p-0">
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="flex items-center gap-2 py-10 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading messages…
              </div>
            ) : messages.length === 0 ? (
              <div className="rounded-xl border border-dashed px-6 py-10 text-center">
                <Bell className="mx-auto h-6 w-6 text-muted-foreground/50" />
                <p className="mt-2 text-sm text-muted-foreground">
                  No messages yet. When the owner writes to <span className="font-medium text-foreground">{me.id}</span>,
                  it shows up here instantly.
                </p>
              </div>
            ) : (
              <div className="unfo-scroll max-h-96 space-y-3 overflow-y-auto pr-1">
                {messages.map((m) => (
                  <button
                    key={m.id}
                    onClick={() => markRead(m)}
                    className={`w-full rounded-xl border p-4 text-left transition-all duration-200 hover:border-primary/40 hover:bg-accent/50 ${
                      m.read ? "bg-card opacity-75" : "bg-accent/60 border-primary/30"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
                        {m.read ? (
                          <MailOpen className="h-3.5 w-3.5" />
                        ) : (
                          <span className="flex items-center gap-1.5 text-primary font-semibold">
                            <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" /> NEW
                          </span>
                        )}
                        from <span className="font-semibold text-foreground">{m.fromId}</span>
                        {m.broadcast && (
                          <Badge variant="secondary" className="px-1.5 py-0 text-[9px] uppercase tracking-wider">
                            Broadcast
                          </Badge>
                        )}
                      </span>
                      <span className="shrink-0 text-[11px] text-muted-foreground">{fmtAgo(m.createdAt)}</span>
                    </div>
                    <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed">{m.content}</p>
                    {!m.read && (
                      <span className="mt-2 inline-flex items-center gap-1 text-[11px] text-primary">
                        <Check className="h-3 w-3" /> Click to mark as read
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Account */}
        <Card className="dash-in lg:col-span-2 rounded-2xl border shadow-[0_1px_2px_rgba(31,30,26,0.04)] h-fit">
          <CardHeader className="pb-3">
            <div className="flex items-center gap-2">
              <Fingerprint className="h-4 w-4 text-primary" />
              <CardTitle className="font-display text-xl">Your ID</CardTitle>
            </div>
            <CardDescription>Works on every site in the network.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="rounded-xl bg-secondary/70 px-4 py-3">
              <div className="text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">UNFO ID</div>
              <div className="mt-0.5 font-display text-2xl font-semibold tracking-tight text-primary">{me.id}</div>
            </div>

            <div>
              <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Change password</div>
              <form onSubmit={changePassword} className="mt-2 space-y-2.5">
                <Input
                  type="password"
                  value={currentPw}
                  onChange={(e) => setCurrentPw(e.target.value)}
                  placeholder="Current password"
                  autoComplete="current-password"
                  className="h-10 rounded-xl text-sm"
                />
                <Input
                  type="password"
                  value={newPw}
                  onChange={(e) => setNewPw(e.target.value)}
                  placeholder="New password (4+ characters)"
                  autoComplete="new-password"
                  className="h-10 rounded-xl text-sm"
                />
                <Button type="submit" disabled={pwBusy} variant="outline" className="h-10 w-full rounded-xl text-sm">
                  {pwBusy && <Loader2 className="mr-2 h-3.5 w-3.5 animate-spin" />}
                  Update password
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Network grid */}
      <Reveal className="mt-14" delay={80}>
        <div className="flex flex-wrap items-end justify-between gap-3">
          <h2 className="font-display text-2xl sm:text-3xl font-semibold tracking-tight">The network</h2>
          <Button variant="ghost" size="sm" onClick={onRefreshSites} className="text-muted-foreground">
            <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Refresh
          </Button>
        </div>
      </Reveal>
      <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {sites.map((site, i) => (
          <Reveal key={site.id} delay={(i % 3) * 110}>
            <SiteCard site={site} index={i} />
          </Reveal>
        ))}
      </div>
    </main>
  );
}
