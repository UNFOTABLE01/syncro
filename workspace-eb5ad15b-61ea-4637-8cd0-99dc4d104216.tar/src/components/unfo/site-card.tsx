"use client";

import { ArrowUpRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { hostnameOf } from "./anime";
import type { Site } from "./types";

const TILES = [
  "linear-gradient(135deg, #1c1c1a 0%, #000000 100%)",
  "linear-gradient(135deg, #4a4a47 0%, #1c1c1a 100%)",
  "linear-gradient(135deg, #8a8778 0%, #56544a 100%)",
  "linear-gradient(135deg, #33332f 0%, #0f0f0e 100%)",
];

export function SiteCard({ site, index }: { site: Site; index: number }) {
  const host = hostnameOf(site.url);
  const tile = TILES[index % TILES.length];

  return (
    <a
      href={site.url}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Visit ${site.name} — ${host}`}
      className="group flex h-full flex-col rounded-2xl border bg-card p-5 sm:p-6 shadow-[0_1px_2px_rgba(31,30,26,0.04)] transition-all duration-300 hover:-translate-y-1.5 hover:shadow-[0_18px_40px_-18px_rgba(0,0,0,0.35)] hover:border-[#000000]/40 focus-visible:ring-2 focus-visible:ring-ring outline-none"
    >
      <div className="flex items-start justify-between gap-3">
        <div
          aria-hidden
          className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl font-display text-xl font-semibold text-white shadow-inner transition-transform duration-300 group-hover:scale-105 group-hover:rotate-3"
          style={{ background: tile }}
        >
          {site.name.charAt(0).toUpperCase()}
        </div>
        <span className="flex h-8 w-8 items-center justify-center rounded-full border bg-secondary/60 text-muted-foreground transition-all duration-300 group-hover:bg-primary group-hover:text-white group-hover:border-primary">
          <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </span>
      </div>

      <h3 className="mt-4 font-display text-xl font-semibold tracking-tight text-foreground">
        {site.name}
      </h3>
      <p className="mt-1.5 flex-1 text-sm leading-relaxed text-muted-foreground">
        {site.description || "A member of the UNFOTABLE network."}
      </p>

      <div className="mt-4 flex items-center justify-between gap-2">
        <Badge variant="secondary" className="max-w-[70%] truncate font-normal text-[11px]">
          {host}
        </Badge>
        <span className="text-xs font-medium text-primary opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          Visit site
        </span>
      </div>
    </a>
  );
}
