import { NextRequest, NextResponse } from 'next/server'
import { getSessionUser, hashPassword, verifyPassword } from '@/lib/auth'

export async function POST(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user) return NextResponse.json({ error: 'Not signed in.' }, { status: 401 })

  try {
    const body = await req.json()
    const current = String(body?.currentPassword ?? '')
    const next = String(body?.newPassword ?? '')

    if (!verifyPassword(current, user.password)) {
      return NextResponse.json({ error: 'Current password is wrong.' }, { status: 400 })
    }
    if (next.length < 4) {
      return NextResponse.json({ error: 'New password must be at least 4 characters.' }, { status: 400 })
    }

    await db.user.update({
      where: { id: user.id },
      data: { password: hashPassword(next) },
    })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Could not change password. Try again.' }, { status: 500 })
  }
}
