import { NextRequest, NextResponse } from 'next/server'
import { getSessionUser } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user) return NextResponse.json({ user: null })
  const unread = await db.message.count({ where: { toId: user.id, read: false } })
  return NextResponse.json({ user: { id: user.id, role: user.role, createdAt: user.createdAt }, unread })
}
