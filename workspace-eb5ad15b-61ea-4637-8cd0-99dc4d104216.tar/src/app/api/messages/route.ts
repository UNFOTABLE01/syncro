import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'

// Signed-in member: their inbox (messages from the owner)
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user) return NextResponse.json({ error: 'Not signed in.' }, { status: 401 })

  const messages = await db.message.findMany({
    where: { toId: user.id },
    orderBy: { createdAt: 'desc' },
    take: 100,
  })
  const unread = messages.filter((m) => !m.read).length
  return NextResponse.json({ messages, unread })
}
