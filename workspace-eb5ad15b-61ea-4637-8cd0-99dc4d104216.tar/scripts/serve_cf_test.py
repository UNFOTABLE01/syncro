#!/usr/bin/env python3
"""Serve download/unfotable-cloudflare/public with the exact security headers
defined in its public/_headers file — to prove the CSP does not break the app
before the user deploys to Cloudflare. Mirrors what Workers/Pages will send."""
import pathlib
from http.server import HTTPServer, SimpleHTTPRequestHandler

ROOT = pathlib.Path("/home/z/my-project/download/unfotable-cloudflare/public")
PORT = 8899

# --- parse _headers (URL pattern -> [(name, value), ...]) ---
rules, current = {}, None
for line in (ROOT / "_headers").read_text(encoding="utf-8").splitlines():
    if not line.strip():
        continue
    if not line.startswith(" "):
        current = line.strip()
        rules.setdefault(current, [])
    elif current is not None:
        name, value = line.strip().split(":", 1)
        rules[current].append((name.strip(), value.strip()))
assert "/*" in rules and any(k == "Content-Security-Policy" for k, _ in rules["/*"]), "bad _headers"

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(ROOT), **kw)

    def end_headers(self):
        for name, value in rules.get("/*", []):
            self.send_header(name, value)
        super().end_headers()

    def log_message(self, *a):
        pass

print(f"Serving {ROOT} on http://127.0.0.1:{PORT} with {len(rules['/*'])} security headers")
HTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
