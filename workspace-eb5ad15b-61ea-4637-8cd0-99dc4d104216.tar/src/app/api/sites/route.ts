import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'

// Public: list every website in the network
export async function GET() {
  const sites = await db.website.findMany({ orderBy: { createdAt: 'asc' } })
  return NextResponse.json({ sites })
}

// Owner only: connect a new website
export async function POST(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user || user.role !== 'owner') {
    return NextResponse.json({ error: 'Owner permission required.' }, { status: 403 })
  }
  try {
    const body = await req.json()
    const name = String(body?.name ?? '').trim()
    let url = String(body?.url ?? '').trim()
    const description = String(body?.description ?? '').trim()

    if (!name) return NextResponse.json({ error: 'Give the website a name.' }, { status: 400 })
    if (!url) return NextResponse.json({ error: 'Enter the website URL.' }, { status: 400 })
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`
    try {
      new URL(url)
    } catch {
      return NextResponse.json({ error: 'That URL does not look valid.' }, { status: 400 })
    }

    const site = await db.website.create({ data: { name, url, description } })
    return NextResponse.json({ site })
  } catch {
    return NextResponse.json({ error: 'Could not add the website.' }, { status: 500 })
  }
}
