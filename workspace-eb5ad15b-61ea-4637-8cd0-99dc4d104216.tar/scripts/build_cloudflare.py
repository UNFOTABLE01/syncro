#!/usr/bin/env python3
"""Assemble the Cloudflare Workers deployment kit.

Reads the verified app files from download/unfotable-site/ (built by
build_site_folder.py — run that first) and wraps them in a Workers
"static assets" project:

  download/unfotable-cloudflare/
  ├── wrangler.jsonc      Workers config (assets-only, no server code)
  ├── package.json        dev/deploy scripts (wrangler)
  ├── README.md           deploy + dev guide
  └── public/
      ├── index.html
      ├── style.css
      ├── app.js
      ├── anime.min.js
      └── _headers        security headers (CSP etc.), applied by Workers/Pages

Also zips to download/unfotable-cloudflare.zip.
"""
import pathlib
import shutil
import zipfile

ROOT = pathlib.Path("/home/z/my-project")
SRC = ROOT / "download/unfotable-site"
DEST = ROOT / "download/unfotable-cloudflare"

# ---------- sanity: source app must be the verified build ----------
for f in ("index.html", "style.css", "app.js", "anime.min.js"):
    assert (SRC / f).exists(), f"missing {SRC/f} — run build_site_folder.py first"
app_js = (SRC / "app.js").read_text(encoding="utf-8")
assert "async function seed()" in app_js and "OwnerView" in app_js, "app.js looks wrong"
assert "e.g. Devanshu" not in app_js, "stale owner hint found in app.js"

# ---------- fresh folder ----------
if DEST.exists():
    shutil.rmtree(DEST)
(DEST / "public").mkdir(parents=True)

for f in ("index.html", "style.css", "app.js", "anime.min.js"):
    shutil.copy2(SRC / f, DEST / "public" / f)

(DEST / "public" / "_headers").write_text("""/*
  X-Content-Type-Options: nosniff
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin
  Permissions-Policy: camera=(), microphone=(), geolocation=(), payment=()
  Cross-Origin-Opener-Policy: same-origin
  Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'
""", encoding="utf-8")

(DEST / "wrangler.jsonc").write_text("""/**
 * UNFOTABLE on Cloudflare Workers — pure static assets, zero server code.
 *
 *   npx wrangler deploy   ->  https://unfotable.<your-subdomain>.workers.dev
 *   npx wrangler dev      ->  http://localhost:8787
 *
 * Rename "name" below to change your *.workers.dev URL.
 * The whole app (index.html / style.css / app.js / anime.min.js) lives in
 * ./public and is served straight from Cloudflare's edge — nothing to hack,
 * no database, no secrets. All member data stays in each visitor's browser.
 */
{
  "$schema": "node_modules/wrangler/config-schema.json",
  "name": "unfotable",
  "compatibility_date": "2026-10-01",
  "assets": {
    "directory": "./public",
    "not_found_handling": "single-page-application"
  }
}
""", encoding="utf-8")

(DEST / "package.json").write_text("""{
  "name": "unfotable",
  "private": true,
  "scripts": {
    "dev": "wrangler dev",
    "deploy": "wrangler deploy"
  },
  "devDependencies": {
    "wrangler": "^4"
  }
}
""", encoding="utf-8")

(DEST / "README.md").write_text("""# UNFOTABLE — Cloudflare Workers edition

One ID. Many worlds. The complete UNFOTABLE network as a static site,
ready for Cloudflare. No server code, no database, no secrets to leak —
every visitor's IDs, passwords (salted SHA-256 hashes), websites and
messages live only in their own browser's localStorage.

## What's inside

```
wrangler.jsonc      Workers config — rename "name" to change your URL
package.json        npm scripts (dev / deploy)
public/
  index.html        the app
  style.css         cream/black theme
  app.js            all logic (auth, dashboards, owner console)
  anime.min.js      anime.js v4, stored locally (works offline)
  _headers          security headers: CSP, nosniff, frame-deny, …
```

## Deploy to Cloudflare Workers (recommended)

```bash
npm install          # installs wrangler once
npx wrangler login   # opens the browser, log in to Cloudflare
npx wrangler deploy  # ships ./public to the edge
```

Your site goes live at **https://unfotable.<your-subdomain>.workers.dev**
(change `"name"` in `wrangler.jsonc` to rename it; add a custom domain in
Dashboard → Workers → your worker → Settings → Domains & Routes).

## Develop locally

```bash
npx wrangler dev     # serves http://localhost:8787 with hot reload
```

## No terminal? Drag & drop instead

1. Zip the four files **inside** `public/` (index.html, style.css,
   app.js, anime.min.js — plus _headers).
2. Cloudflare Dashboard → **Workers & Pages → Create → Pages → Upload assets**.
3. Drop the zip → your site is live on a `*.pages.dev` URL.
   (Pages reads the same `_headers` file.)

## How IDs work (for you, the owner)

- Every visitor gets a fresh, empty network in their browser — all IDs are
  free, nothing is pre-registered, and the only pre-connected website is
  **Splid** (https://splid.unfo.workers.dev/).
- Whoever registers the ID **Devanshu** (any letter case) with a password of
  their choice automatically gets the **owner console**: see every ID,
  remove IDs, message any member, broadcast, curate the website grid.
  This is deliberately not advertised anywhere on the site.
- Because storage is per-browser, members only exist on the device where
  they registered — that is the trade-off for having zero backend.
  Clearing site data resets the network.

Rebuild from source: `python3 scripts/build_site_folder.py && python3 scripts/build_cloudflare.py`
""", encoding="utf-8")

# ---------- zip ----------
ZIP = ROOT / "download/unfotable-cloudflare.zip"
if ZIP.exists():
    ZIP.unlink()
with zipfile.ZipFile(ZIP, "w", zipfile.ZIP_DEFLATED) as z:
    for f in sorted(DEST.rglob("*")):
        if f.is_file():
            z.write(f, f.relative_to(DEST.parent))

for f in sorted(DEST.rglob("*")):
    if f.is_file():
        print(f"  {f.relative_to(DEST)!s:<24} {f.stat().st_size/1024:8.1f} KB")
print(f"  zip {ZIP.stat().st_size/1024:.1f} KB")
print(f"OK -> {DEST}")
