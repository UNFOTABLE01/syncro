import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'

// Owner only: the full portfolio of UNFOTABLE
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user || user.role !== 'owner') {
    return NextResponse.json({ error: 'Owner permission required.' }, { status: 403 })
  }

  const [totalIds, totalSites, totalMessages, unreadMessages, users, sites, recentMessages] =
    await Promise.all([
      db.user.count(),
      db.website.count(),
      db.message.count(),
      db.message.count({ where: { read: false } }),
      db.user.findMany({ orderBy: { createdAt: 'desc' }, select: { id: true, role: true, createdAt: true } }),
      db.website.findMany({ orderBy: { createdAt: 'asc' } }),
      db.message.findMany({ orderBy: { createdAt: 'desc' }, take: 12 }),
    ])

  // Registrations per day for the last 14 days
  const days: { date: string; count: number }[] = []
  const now = new Date()
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i)
    const next = new Date(now.getFullYear(), now.getMonth(), now.getDate() - i + 1)
    const count = users.filter((u) => u.createdAt >= d && u.createdAt < next).length
    days.push({ date: d.toISOString().slice(5, 10), count })
  }

  return NextResponse.json({
    stats: {
      totalIds,
      totalSites,
      totalMessages,
      unreadMessages,
      members: totalIds - 1, // excluding the owner
    },
    growth: days,
    users,
    sites,
    recentMessages: recentMessages.map((m) => ({
      id: m.id,
      toId: m.toId,
      broadcast: m.broadcast,
      content: m.content.slice(0, 120),
      createdAt: m.createdAt,
    })),
  })
}
