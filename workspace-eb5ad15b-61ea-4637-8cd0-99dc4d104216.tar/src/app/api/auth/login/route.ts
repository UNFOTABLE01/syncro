import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { verifyPassword, signSession, cookieOptions, SESSION_COOKIE } from '@/lib/auth'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const id = String(body?.id ?? '').trim()
    const password = String(body?.password ?? '')

    if (!id || !password) {
      return NextResponse.json({ error: 'Enter your ID and password.' }, { status: 400 })
    }

    const user = await db.user.findUnique({ where: { id } })
    if (!user || !verifyPassword(password, user.password)) {
      return NextResponse.json({ error: 'Wrong ID or password.' }, { status: 401 })
    }

    const res = NextResponse.json({
      user: { id: user.id, role: user.role, createdAt: user.createdAt },
    })
    res.cookies.set(SESSION_COOKIE, signSession(user.id), cookieOptions())
    return res
  } catch {
    return NextResponse.json({ error: 'Login failed. Try again.' }, { status: 500 })
  }
}
