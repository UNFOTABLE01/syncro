/* ================= dashboard shells ================= */
function dashHead(badge, title, sub) {
  return (
    '<div class="dash-head a-rise">' +
      '<span class="badge badge-ink">' + badge + "</span>" +
      '<h1 class="dash-title serif">' + title + "</h1>" +
      '<p class="dash-sub">' + sub + "</p>" +
    "</div>"
  );
}

function statCard(ico, label, num, cap) {
  return (
    '<div class="card stat-card a-rise">' +
      '<div class="stat-ico">' + ico + " " + esc(label) + "</div>" +
      '<div class="num serif">' + num + "</div>" +
      '<div class="cap">' + esc(cap) + "</div>" +
    "</div>"
  );
}

function rowItemHTML(s, i, opts) {
  opts = opts || {};
  return (
    '<div class="row-item">' +
      '<span class="row-tile serif" style="background:' + tileOf(i) + '">' + esc((s.name || "?").charAt(0).toUpperCase()) + "</span>" +
      '<span class="row-main">' +
        '<span class="row-name">' + esc(s.name) + '<span class="row-idx">#' + (i + 1) + "</span></span>" +
        '<span class="row-meta">' + esc(s.url) + "</span>" +
      "</span>" +
      (opts.extra || "") +
    "</div>"
  );
}

function siteRowHTML(s, i) {
  const editing = editingSiteId === s.id;
  if (editing) {
    return (
      '<div class="card card-pad" style="border-color:rgba(0,0,0,.4)">' +
        '<div class="action-row" style="justify-content:space-between">' +
          '<span class="badge badge-soft">Editing #' + (i + 1) + " · changes go live instantly</span>" +
        "</div>" +
        '<div class="edit-grid">' +
          '<div><label class="label">Name</label><input class="input" id="ed-name" value="' + esc(s.name) + '" maxlength="40" /></div>' +
          '<div><label class="label">URL</label><input class="input" id="ed-url" value="' + esc(s.url) + '" placeholder="https://…" /></div>' +
          '<div class="full"><label class="label">Description</label><textarea class="textarea" id="ed-desc" style="min-height:64px" maxlength="220">' + esc(s.description || "") + "</textarea></div>" +
        "</div>" +
        '<div class="action-row" style="margin-top:12px">' +
          '<button class="btn btn-primary btn-sm" onclick="A.saveSite(\'' + s.id + '\')">Save & publish</button>' +
          '<button class="btn btn-ghost btn-sm" onclick="A.cancelEdit()">Cancel</button>' +
        "</div>" +
      "</div>"
    );
  }
  return (
    '<div class="card card-pad">' +
      '<div style="display:flex;align-items:center;gap:12px">' +
        '<span class="row-tile serif" style="background:' + tileOf(i) + ';height:40px;width:40px">' + esc((s.name || "?").charAt(0).toUpperCase()) + "</span>" +
        '<span class="row-main">' +
          '<span class="row-name">' + esc(s.name) + '<span class="row-idx">#' + (i + 1) + "</span></span>" +
          '<span class="row-meta">' + esc(s.url) + "</span>" +
        "</span>" +
        '<span class="action-row">' +
          '<a class="btn btn-outline btn-sm" href="' + esc(s.url) + '" target="_blank" rel="noopener noreferrer">Open ↗</a>' +
          '<button class="btn btn-outline btn-sm" onclick="A.editSite(\'' + s.id + '\')">Edit</button>' +
          '<button class="btn btn-danger btn-sm" onclick="A.delSite(\'' + s.id + '\')">Remove</button>' +
        "</span>" +
      "</div>" +
      (s.description ? '<p style="margin-top:10px;font-size:13.5px;color:var(--muted)">' + esc(s.description) + "</p>" : "") +
    "</div>"
  );
}

function pwFormHTML(prefix) {
  return (
    '<form onsubmit="return A.changePw(event, \'' + prefix + '\')">' +
      '<div class="field"><label class="label">Current password</label><input class="input" id="' + prefix + '-cur" type="password" autocomplete="current-password" /></div>' +
      '<div class="field"><label class="label">New password</label><input class="input" id="' + prefix + '-new" type="password" autocomplete="new-password" placeholder="At least 6 characters" /></div>' +
      '<button class="btn btn-primary btn-sm" type="submit">Update password</button>' +
    "</form>"
  );
}

/* ================= user dashboard ================= */
function inboxHTML(u) {
  const list = allMsgs().filter(m => m.to === u.id).sort((a, b) => b.ts - a.ts);
  const unread = list.filter(m => !m.read).length;
  let inner;
  if (!list.length) {
    inner = '<div class="empty">No messages yet — the owner can reach you here, straight to your ID.</div>';
  } else {
    inner = list.map(m =>
      '<div class="msg-item ' + (m.read ? "" : "unread") + '">' +
        '<div class="msg-top">' +
          '<span class="msg-from">✉ ' + esc(m.from) + (m.read ? "" : ' <span class="badge badge-ink" style="font-size:9px;padding:2px 7px;margin-left:6px">NEW</span>') + "</span>" +
          '<span class="msg-time">' + esc(fmtFull(m.ts)) + "</span>" +
        "</div>" +
        '<div class="msg-body">' + esc(m.content) + "</div>" +
        (m.read ? "" : '<div class="msg-actions"><button class="btn btn-ghost btn-sm" onclick="A.msgRead(\'' + m.id + '\')">Mark as read</button></div>') +
      "</div>"
    ).join("");
  }
  return (
    '<div style="display:flex;align-items:center;justify-content:space-between;gap:10px">' +
      '<div><div class="card-title serif">Inbox</div><div class="card-sub">Messages delivered to your ID</div></div>' +
      (unread ? '<span class="badge">' + unread + " unread</span>" : "") +
    "</div>" +
    '<div style="display:grid;gap:10px;margin-top:14px">' + inner + "</div>" +
    (list.length && unread
      ? '<div class="msg-actions"><button class="btn btn-outline btn-sm" style="margin-top:10px" onclick="A.markAllRead()">Mark all as read</button></div>'
      : "")
  );
}

function UserView(u) {
  const list = allSites();
  const unread = allMsgs().filter(m => m.to === u.id && !m.read).length;
  return (
    '<main class="dash">' +
      '<div class="wrap">' +
        dashHead("UNFO MEMBER", "Dashboard", "Signed in as <b>" + esc(u.id) + "</b> — one ID for the whole network.") +
        '<div class="stats-row">' +
          statCard("🆔", "Your ID", esc(u.id), "yours to keep, forever") +
          statCard("🌐", "Sites unlocked", list.length, "open with this one ID") +
          statCard("✉", "Unread messages", unread, "waiting in your inbox") +
          statCard("📅", "Member since", esc(fmtFull(u.createdAt)), "day you claimed it") +
        "</div>" +
        '<div class="dash-grid dash-grid-3 mt-16">' +
          '<div style="display:grid;gap:16px;align-content:start">' +
            '<div class="card card-pad a-rise"><div id="inbox">' + inboxHTML(u) + "</div></div>" +
            '<div class="card card-pad a-rise">' +
              '<div class="card-title serif">The network</div><div class="card-sub">Every connected website — one click away</div>' +
              '<div style="display:grid;gap:10px;margin-top:14px">' +
                (list.length
                  ? list.map((s, i) => rowItemHTML(s, i, {
                      extra: '<a class="btn btn-outline btn-sm" href="' + esc(s.url) + '" target="_blank" rel="noopener noreferrer">Open ↗</a>'
                    })).join("")
                  : '<div class="empty">No websites yet — the owner curates this grid.</div>') +
              "</div>" +
            "</div>" +
          "</div>" +
          '<div style="display:grid;gap:16px;align-content:start">' +
            '<div class="card card-pad a-rise" style="background:linear-gradient(160deg,#fff 0%,#f5efe7 130%)">' +
              '<span class="badge badge-ink">YOUR UNFO ID</span>' +
              '<div class="serif" style="font-size:34px;font-weight:600;margin-top:12px;letter-spacing:-.01em;word-break:break-all">' + esc(u.id) + "</div>" +
              '<p style="margin-top:8px;font-size:13.5px;color:var(--muted)">Use this ID with your password to sign back in from any device. It unlocks every website in the UNFOTABLE group.</p>' +
              '<div class="action-row" style="margin-top:14px">' +
                '<button class="btn btn-outline btn-sm" onclick="A.copyId()">Copy ID</button>' +
                '<span class="badge badge-soft">Member since ' + esc(fmtFull(u.createdAt)) + "</span>" +
              "</div>" +
            "</div>" +
            '<div class="card card-pad a-rise">' +
              '<div class="card-title serif">Security</div><div class="card-sub">Change your password anytime</div>' +
              '<div style="margin-top:14px">' + pwFormHTML("upw") + "</div>" +
            "</div>" +
          "</div>" +
        "</div>" +
      "</div>" +
    "</main>"
  );
}

function startInboxPolling(u) {
  stopTimers();
  inboxTimer = setInterval(() => {
    if (screen !== "dash") return stopTimers();
    const cur = me();
    if (!cur || cur.role === "owner") return stopTimers();
    const box = $("#inbox");
    if (box) box.innerHTML = inboxHTML(cur);
  }, 4000);
}

/* ================= owner console ================= */
function growthData() {
  const days = [];
  const now = new Date(); now.setHours(0, 0, 0, 0);
  for (let i = 13; i >= 0; i--) {
    const d = new Date(now.getTime() - i * 864e5);
    days.push({ key: dayKey(d.getTime()), label: fmtDay(d.getTime()), count: 0 });
  }
  allUsers().forEach(u => {
    const k = dayKey(u.createdAt);
    const hit = days.find(x => x.key === k);
    if (hit) hit.count++;
  });
  return days;
}

function chartHTML() {
  const data = growthData();
  const max = Math.max(1, ...data.map(d => d.count));
  return (
    '<div class="chart">' +
      data.map(d =>
        '<div class="chart-col">' +
          '<div class="growth-bar" style="height:' + Math.max(3, Math.round((d.count / max) * 148)) + 'px" title="' + d.label + ": " + d.count + ' new ID(s)"></div>' +
          '<span class="chart-day">' + d.label + "</span>" +
        "</div>"
      ).join("") +
    "</div>"
  );
}

function OwnerView(u) {
  const others = allUsers().filter(x => x.id !== u.id);
  const list = allSites();
  const sent = allMsgs().filter(m => m.from === u.id).sort((a, b) => b.ts - a.ts);
  const unreadForMembers = allMsgs().filter(m => !m.read && m.to !== u.id).length;

  let tabContent = "";
  if (dashTab === "portfolio") {
    const recent = sent.slice(0, 5);
    tabContent =
      '<div class="dash-grid dash-grid-3 mt-16">' +
        '<div class="card card-pad a-rise">' +
          '<div class="card-title serif">New IDs — last 14 days</div><div class="card-sub">How fast the network is growing.</div>' +
          chartHTML() +
        "</div>" +
        '<div style="display:grid;gap:16px;align-content:start">' +
          '<div class="card card-pad a-rise">' +
            '<div class="card-title serif">Network overview</div><div class="card-sub">Every connected website.</div>' +
            '<div style="display:grid;gap:10px;margin-top:14px">' +
              (list.length ? list.map((s, i) => rowItemHTML(s, i, { extra: '<a class="btn btn-outline btn-sm" href="' + esc(s.url) + '" target="_blank" rel="noopener noreferrer">↗</a>' })).join("")
                : '<div class="empty">No websites yet — add one from the Websites tab.</div>') +
            "</div>" +
          "</div>" +
          '<div class="card card-pad a-rise">' +
            '<div class="card-title serif">Recent messages</div><div class="card-sub">The latest things you sent.</div>' +
            '<div style="display:grid;gap:10px;margin-top:14px">' +
              (recent.length
                ? recent.map(m =>
                    '<div class="msg-item"><div class="msg-top"><span class="msg-from">→ ' + esc(m.to) + (m.broadcast ? ' <span class="badge badge-soft" style="font-size:9px;padding:2px 7px">BROADCAST</span>' : "") + '</span><span class="msg-time">' + esc(fmtFull(m.ts)) + "</span></div>" +
                    '<div class="msg-body">' + esc(m.content.length > 120 ? m.content.slice(0, 120) + "…" : m.content) + "</div></div>"
                  ).join("")
                : '<div class="empty">Nothing sent yet — write to a member from the Members tab.</div>') +
            "</div>" +
          "</div>" +
        "</div>" +
      "</div>";
  } else if (dashTab === "websites") {
    tabContent =
      '<div class="card card-pad a-rise mt-16">' +
        '<div class="card-title serif">Add a website</div><div class="card-sub">It goes live on the public grid the moment you save.</div>' +
        '<div class="edit-grid" style="margin-top:14px">' +
          '<div><label class="label">Name</label><input class="input" id="ns-name" placeholder="e.g. Pulse" maxlength="40" /></div>' +
          '<div><label class="label">URL</label><input class="input" id="ns-url" placeholder="https://…" /></div>' +
          '<div class="full"><label class="label">Description <span style="text-transform:none;letter-spacing:0">(optional)</span></label><input class="input" id="ns-desc" placeholder="One line about this world" maxlength="220" /></div>' +
        "</div>" +
        '<button class="btn btn-primary btn-sm" style="margin-top:12px" onclick="A.addSite()">+ Add website</button>' +
      "</div>" +
      '<div style="display:grid;gap:12px;margin-top:16px">' +
        (list.length
          ? list.map((s, i) => '<div class="a-rise">' + siteRowHTML(s, i) + "</div>").join("")
          : '<div class="empty">The grid is empty — add your first website above.</div>') +
      "</div>";
  } else if (dashTab === "members") {
    const compose = msgTargetId
      ? '<div class="card card-pad a-rise" style="border-color:rgba(0,0,0,.45)">' +
          '<div class="card-title serif">Message → ' + esc(msgTargetId) + "</div>" +
          '<textarea class="textarea" id="dm-text" style="margin-top:10px" placeholder="Write something for ' + esc(msgTargetId) + '…"></textarea>' +
          '<div class="action-row" style="margin-top:12px">' +
            '<button class="btn btn-primary btn-sm" onclick="A.sendCompose()">Send message</button>' +
            '<button class="btn btn-ghost btn-sm" onclick="A.cancelCompose()">Cancel</button>' +
          "</div>" +
        "</div>"
      : "";
    tabContent =
      compose +
      '<div class="card card-pad a-rise mt-16">' +
        '<div class="card-title serif">Broadcast</div><div class="card-sub">One message, delivered to every member ID.</div>' +
        '<textarea class="textarea" id="bc-text" style="margin-top:10px" placeholder="Network announcement…"></textarea>' +
        '<div class="action-row" style="margin-top:12px">' +
          '<button class="btn btn-primary btn-sm" onclick="A.broadcast()" ' + (others.length ? "" : "disabled") + ">Broadcast to " + others.length + " member" + (others.length === 1 ? "" : "s") + "</button>" +
        "</div>" +
      "</div>" +
      '<div class="card card-pad a-rise mt-16">' +
        '<div class="card-title serif">Member IDs</div><div class="card-sub">' + others.length + ' registered' + (others.length ? " — remove an ID or write to it directly" : "") + '</div>' +
        '<div class="table-wrap" style="margin-top:12px">' +
          (others.length
            ? '<table class="data"><thead><tr><th>Member</th><th>Role</th><th>Joined</th><th>Unread</th><th style="text-align:right">Actions</th></tr></thead><tbody>' +
              others.map(x => {
                const un = allMsgs().filter(m => m.to === x.id && !m.read).length;
                return (
                  "<tr>" +
                    '<td><span style="display:inline-flex;align-items:center;gap:10px">' +
                      '<span class="avatar serif" style="background:linear-gradient(135deg,#3d3d3a,#000)">' + esc(x.id.charAt(0).toUpperCase()) + "</span>" +
                      "<b>" + esc(x.id) + "</b></span></td>" +
                    '<td><span class="badge badge-soft">' + esc(x.role) + "</span></td>" +
                    "<td>" + esc(fmtFull(x.createdAt)) + "</td>" +
                    "<td>" + (un ? '<span class="badge badge-ink" style="font-size:10px;padding:2px 8px">' + un + "</span>" : "—") + "</td>" +
                    '<td style="text-align:right"><span class="action-row" style="justify-content:flex-end">' +
                      '<button class="btn btn-outline btn-sm" onclick="A.msgMember(\'' + x.id + '\')">Message</button>' +
                      '<button class="btn btn-danger btn-sm" onclick="A.removeMember(\'' + x.id + '\')">Remove</button>' +
                    "</span></td>" +
                  "</tr>"
                );
              }).join("") +
              "</tbody></table>"
            : '<div class="empty" style="margin-top:6px">No member IDs yet. When someone creates one, it appears here.</div>') +
        "</div>" +
      "</div>";
  } else {
    tabContent =
      '<div class="dash-grid dash-grid-2 mt-16">' +
        '<div class="card card-pad a-rise">' +
          '<div class="card-title serif">Owner password</div><div class="card-sub">Keep the console locked down.</div>' +
          '<div style="margin-top:14px">' + pwFormHTML("opw") + "</div>" +
        "</div>" +
        '<div class="card card-pad a-rise">' +
          '<div class="card-title serif">How this edition stores data</div>' +
          '<p style="margin-top:10px;font-size:14px;color:var(--muted)">This standalone edition of UNFOTABLE keeps every ID, password hash, website and message in this browser\'s local storage — nothing leaves your machine. Clearing the browser\'s site data resets the network to its original state: zero registered IDs + the Splid website — every ID is free to claim.</p>' +
          '<div class="action-row" style="margin-top:14px">' +
            '<span class="badge badge-soft">ID · ' + esc(u.id) + "</span>" +
            '<span class="badge badge-soft">Members · ' + others.length + "</span>" +
            '<span class="badge badge-soft">Websites · ' + list.length + "</span>" +
          "</div>" +
        "</div>" +
      "</div>";
  }

  return (
    '<main class="dash">' +
      '<div class="wrap">' +
        dashHead("👑 OWNER · Full permissions", "Owner console", "Signed in as <b>" + esc(u.id) + "</b> — see every ID, curate the network, and reach any member directly.") +
        '<div class="stats-row">' +
          statCard("👥", "Member IDs", others.length, "excluding you") +
          statCard("🌐", "Websites", list.length, "in the network") +
          statCard("✉", "Messages sent", sent.length, "all time") +
          statCard("📣", "Undelivered", unreadForMembers, "awaiting members") +
        "</div>" +
        '<div class="tabbar mt-24" style="max-width:640px">' +
          [["portfolio", "Portfolio"], ["websites", "Websites"], ["members", "Members"], ["settings", "Settings"]]
            .map(t => '<button class="tab ' + (dashTab === t[0] ? "active" : "") + '" onclick="A.dashTab(\'' + t[0] + '\')">' + t[1] + "</button>")
            .join("") +
        "</div>" +
        tabContent +
      "</div>" +
    "</main>"
  );
}

function runDashAnims(isOwner) {
  an(".dash .a-rise", { opacity: [0, 1], translateY: [24, 0], duration: 750, delay: stg ? stg(70) : (el, i) => i * 70, ease: "outExpo" });
  if (canAnime) {
    const bars = $$(".growth-bar");
    bars.forEach(b => { b.style.transform = "scaleY(0)"; });
    an(bars, { scaleY: [0, 1], duration: 800, delay: stg ? stg(35) : (el, i) => i * 35, ease: "outExpo" });
  }
  safetyShow();
}

/* ================= actions ================= */
const A = {

  /* navigation */
  go(s) { screen = s; render(); window.scrollTo({ top: 0, behavior: "auto" }); },
  openAuth(tab) { authTab = tab; screen = "auth"; render(); window.scrollTo({ top: 0 }); },
  authMode(tab) { authTab = tab; render(); },
  dashTab(t) { dashTab = t; editingSiteId = null; msgTargetId = null; render(); },
  scrollGrid() { const el = $("#network-grid"); if (el) el.scrollIntoView({ behavior: "smooth" }); },
  footerDash() { const u = me(); if (u) A.go("dash"); else A.openAuth("login"); },

  /* auth */
  async submitAuth(e) {
    e.preventDefault();
    const idEl = $("#f-id"), pwEl = $("#f-pw");
    const id = (idEl.value || "").trim();
    const pw = pwEl.value || "";
    if (!id || !pw) return toast("Missing details", "Enter both your ID and password.");
    if (authTab === "login") {
      const u = allUsers().find(x => x.id === id);
      if (!u) return toast("No such ID", "Check the spelling — IDs are 8–24 letters and digits.");
      const h = await hashPw(pw, u.salt);
      if (h !== u.hash) return toast("Wrong password", "Try again — you can reset nothing here, passwords matter.");
      /* Safety: the Devanshu ID always carries owner permissions. */
      if (u.id.toLowerCase() === "devanshu" && u.role !== "owner") {
        u.role = "owner";
        saveUsers(allUsers().map(x => (x.id === u.id ? u : x)));
      }
      write(K.sess, u.id);
      toast("Signed in as " + u.id, u.role === "owner" ? "Welcome back — the owner console is ready." : "Welcome to UNFOTABLE.");
      A.go("dash");
    } else {
      if (!validId(id)) return toast("Invalid ID", "Use 8–24 characters — letters and digits only.");
      if (allUsers().some(x => x.id.toLowerCase() === id.toLowerCase())) return toast("ID already taken", "Pick another 8+ character ID.");
      if (pw.length < 6) return toast("Weak password", "Use at least 6 characters — you will need it to sign back in.");
      const salt = "unfo-" + Math.random().toString(36).slice(2, 8);
      /* Every ID is free — and the ID "Devanshu" (any letter case) carries full owner permissions. */
      const isOwner = id.toLowerCase() === "devanshu";
      const user = { id, salt, hash: await hashPw(pw, salt), role: isOwner ? "owner" : "user", createdAt: Date.now() };
      saveUsers(allUsers().concat([user]));
      write(K.sess, user.id);
      toast(isOwner ? "Owner ID claimed" : "Welcome to UNFOTABLE", isOwner ? id + " now holds full owner access." : "Your ID " + id + " is live across the network.");
      A.go("dash");
    }
    return false;
  },
  signOut() {
    localStorage.removeItem(K.sess);
    toast("Signed out", "Your ID will be here when you come back.");
    A.go("public");
  },
  async changePw(e, prefix) {
    e.preventDefault();
    const u = me();
    if (!u) return false;
    const cur = $("#" + prefix + "-cur").value || "";
    const nw = $("#" + prefix + "-new").value || "";
    const h = await hashPw(cur, u.salt);
    if (h !== u.hash) return toast("Wrong current password", "The console stays locked without it.");
    if (nw.length < 6) return toast("Too short", "New password needs at least 6 characters.");
    const users = allUsers();
    const hit = users.find(x => x.id === u.id);
    hit.salt = "unfo-" + Math.random().toString(36).slice(2, 8);
    hit.hash = await hashPw(nw, hit.salt);
    saveUsers(users);
    toast("Password updated", "Use the new one next time you sign in.");
    e.target.reset();
    return false;
  },

  /* user dash */
  copyId() {
    const u = me();
    if (!u) return;
    const done = () => toast("Copied", u.id + " is on your clipboard.");
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(u.id).then(done, () => toast("Copy failed", "Select and copy it manually: " + u.id));
    else toast("Your ID", u.id);
  },
  msgRead(id) {
    const msgs = allMsgs();
    const m = msgs.find(x => x.id === id);
    if (m) { m.read = true; saveMsgs(msgs); }
    const box = $("#inbox");
    const u = me();
    if (box && u) box.innerHTML = inboxHTML(u);
  },
  markAllRead() {
    const u = me();
    if (!u) return;
    const msgs = allMsgs().map(m => (m.to === u.id ? Object.assign({}, m, { read: true }) : m));
    saveMsgs(msgs);
    toast("Inbox cleared", "All messages marked as read.");
    render();
  },

  /* owner — websites (live editing) */
  addSite() {
    const name = ($("#ns-name").value || "").trim();
    const url = ($("#ns-url").value || "").trim();
    const desc = ($("#ns-desc").value || "").trim();
    if (!name) return toast("Name required", "Give the website a short name.");
    if (!/^https?:\/\/.+\..+/.test(url)) return toast("Invalid URL", "Use a full address like https://example.com");
    const sites = read(K.sites, []);
    sites.push({ id: uid(), name, url, description: desc, createdAt: Date.now() });
    saveSites(sites);
    toast("Website published", name + " is live on the public grid.");
    render();
  },
  editSite(id) { editingSiteId = id; render(); window.scrollTo({ top: $("#app").scrollHeight, behavior: "smooth" }); },
  cancelEdit() { editingSiteId = null; render(); },
  saveSite(id) {
    const name = ($("#ed-name").value || "").trim();
    const url = ($("#ed-url").value || "").trim();
    const desc = ($("#ed-desc").value || "").trim();
    if (!name) return toast("Name required", "The tile needs a name.");
    if (!/^https?:\/\/.+\..+/.test(url)) return toast("Invalid URL", "Use a full address like https://example.com");
    const sites = read(K.sites, []);
    const s = sites.find(x => x.id === id);
    if (s) { s.name = name; s.url = url; s.description = desc; saveSites(sites); }
    editingSiteId = null;
    toast("Saved & live", name + " has been updated everywhere.");
    render();
  },
  delSite(id) {
    const sites = read(K.sites, []);
    const s = sites.find(x => x.id === id);
    confirmBox("Remove website?", (s ? s.name : "This site") + " will disappear from the public grid immediately.", "Remove", () => {
      saveSites(sites.filter(x => x.id !== id));
      toast("Website removed", "The grid updates for everyone right away.");
      render();
    });
  },

  /* owner — members & messages */
  msgMember(id) { msgTargetId = id; dashTab = "members"; render(); window.scrollTo({ top: 0, behavior: "smooth" }); },
  cancelCompose() { msgTargetId = null; render(); },
  sendCompose() {
    const u = me();
    const txt = ($("#dm-text").value || "").trim();
    if (!u || !msgTargetId) return;
    if (!txt) return toast("Empty message", "Write something first.");
    const msgs = allMsgs();
    msgs.push({ id: uid(), to: msgTargetId, from: u.id, content: txt, read: false, broadcast: false, ts: Date.now() });
    saveMsgs(msgs);
    msgTargetId = null;
    toast("Message sent", "Delivered to " + msgTargetId + "'s inbox.");
    render();
  },
  broadcast() {
    const u = me();
    const txt = ($("#bc-text").value || "").trim();
    if (!u) return;
    if (!txt) return toast("Empty broadcast", "Write the announcement first.");
    const targets = allUsers().filter(x => x.role !== "owner");
    if (!targets.length) return toast("No members yet", "Nobody to broadcast to right now.");
    const msgs = allMsgs();
    const ts = Date.now();
    targets.forEach(t => msgs.push({ id: uid(), to: t.id, from: u.id, content: txt, read: false, broadcast: true, ts }));
    saveMsgs(msgs);
    toast("Broadcast sent", "Delivered to " + targets.length + " member" + (targets.length === 1 ? "" : "s") + ".");
    render();
  },
  removeMember(id) {
    const target = allUsers().find(x => x.id === id);
    if (!target) return;
    if (target.role === "owner") return toast("Not allowed", "The owner ID cannot be removed.");
    confirmBox("Remove ID " + id + "?", "They will lose access to the network, and their messages will be erased. This cannot be undone.", "Remove ID", () => {
      saveUsers(allUsers().filter(x => x.id !== id));
      saveMsgs(allMsgs().filter(m => m.to !== id && m.from !== id));
      if (msgTargetId === id) msgTargetId = null;
      toast("ID removed", id + " is no longer part of UNFOTABLE.");
      render();
    });
  },

  /* modal */
  modalCancel() { $("#modal-mask").classList.remove("open"); modalCb = null; },
  modalOk() { const cb = modalCb; A.modalCancel(); if (cb) cb(); }
};
window.A = A;

/* ================= render + init ================= */
function render() {
  stopTimers();
  const u = me();
  renderHeader(u);
  const app = $("#app");
  if (screen === "auth") {
    app.innerHTML = AuthView();
    runAuthAnims();
  } else if (screen === "dash" && u) {
    app.innerHTML = u.role === "owner" ? OwnerView(u) : UserView(u);
    runDashAnims(u.role === "owner");
    if (u.role !== "owner") startInboxPolling(u);
  } else {
    app.innerHTML = PublicView(u);
    runPublicAnims();
  }
}

async function init() {
  $("#ft-year").textContent = String(new Date().getFullYear());
  await seed();
  $("#modal-mask").addEventListener("click", e => { if (e.target.id === "modal-mask") A.modalCancel(); });
  $("#modal-ok").addEventListener("click", () => A.modalOk());
  render();
}

init();
