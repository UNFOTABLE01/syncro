import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

async function main() {
  // ALL IDs are free — no account is pre-registered on purpose.
  // Whoever claims the ID "Devanshu" (any letter case) gets the owner role
  // automatically at registration (see src/app/api/auth/register/route.ts).

  // The single pre-connected website of the network. Owner adds more later.
  const siteCount = await db.website.count()
  if (siteCount === 0) {
    await db.website.create({
      data: {
        name: 'Splid',
        url: 'https://splid.unfo.workers.dev/',
        description:
          'The first member of the UNFOTABLE network — a live app running on Cloudflare Workers.',
      },
    })
  }

  const users = await db.user.count()
  console.log(
    `Seed complete: ${users} user(s) registered, Splid website ready. All IDs are free to claim — "Devanshu" unlocks the owner console.`
  )
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(() => db.$disconnect())
