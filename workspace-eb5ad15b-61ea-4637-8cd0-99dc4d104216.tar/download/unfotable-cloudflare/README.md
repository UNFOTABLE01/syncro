# UNFOTABLE — Cloudflare Workers edition

One ID. Many worlds. The complete UNFOTABLE network as a static site,
ready for Cloudflare. No server code, no database, no secrets to leak —
every visitor's IDs, passwords (salted SHA-256 hashes), websites and
messages live only in their own browser's localStorage.

## What's inside

```
wrangler.jsonc      Workers config — rename "name" to change your URL
package.json        npm scripts (dev / deploy)
public/
  index.html        the app
  style.css         cream/black theme
  app.js            all logic (auth, dashboards, owner console)
  anime.min.js      anime.js v4, stored locally (works offline)
  _headers          security headers: CSP, nosniff, frame-deny, …
```

## Deploy to Cloudflare Workers (recommended)

```bash
npm install          # installs wrangler once
npx wrangler login   # opens the browser, log in to Cloudflare
npx wrangler deploy  # ships ./public to the edge
```

Your site goes live at **https://unfotable.<your-subdomain>.workers.dev**
(change `"name"` in `wrangler.jsonc` to rename it; add a custom domain in
Dashboard → Workers → your worker → Settings → Domains & Routes).

## Develop locally

```bash
npx wrangler dev     # serves http://localhost:8787 with hot reload
```

## No terminal? Drag & drop instead

1. Zip the four files **inside** `public/` (index.html, style.css,
   app.js, anime.min.js — plus _headers).
2. Cloudflare Dashboard → **Workers & Pages → Create → Pages → Upload assets**.
3. Drop the zip → your site is live on a `*.pages.dev` URL.
   (Pages reads the same `_headers` file.)

## How IDs work (for you, the owner)

- Every visitor gets a fresh, empty network in their browser — all IDs are
  free, nothing is pre-registered, and the only pre-connected website is
  **Splid** (https://splid.unfo.workers.dev/).
- Whoever registers the ID **Devanshu** (any letter case) with a password of
  their choice automatically gets the **owner console**: see every ID,
  remove IDs, message any member, broadcast, curate the website grid.
  This is deliberately not advertised anywhere on the site.
- Because storage is per-browser, members only exist on the device where
  they registered — that is the trade-off for having zero backend.
  Clearing site data resets the network.

Rebuild from source: `python3 scripts/build_site_folder.py && python3 scripts/build_cloudflare.py`
