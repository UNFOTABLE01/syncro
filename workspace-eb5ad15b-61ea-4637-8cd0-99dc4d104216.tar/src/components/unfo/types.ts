export type Role = "owner" | "user";

export type Me = {
  id: string;
  role: Role;
  createdAt: string;
};

export type Site = {
  id: string;
  name: string;
  url: string;
  description: string;
  createdAt: string;
};

export type Msg = {
  id: string;
  toId: string;
  fromId: string;
  content: string;
  broadcast: boolean;
  read: boolean;
  createdAt: string;
};

export type MemberRow = {
  id: string;
  role: string;
  createdAt: string;
  messages: number;
};

export type PortfolioStats = {
  totalIds: number;
  totalSites: number;
  totalMessages: number;
  unreadMessages: number;
  members: number;
};

export type GrowthDay = { date: string; count: number };

export type Portfolio = {
  stats: PortfolioStats;
  growth: GrowthDay[];
  users: { id: string; role: string; createdAt: string }[];
  sites: Site[];
  recentMessages: {
    id: string;
    toId: string;
    broadcast: boolean;
    content: string;
    createdAt: string;
  }[];
};
