import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'

// Owner only: see every ID registered in UNFOTABLE
export async function GET(req: NextRequest) {
  const user = await getSessionUser(req)
  if (!user || user.role !== 'owner') {
    return NextResponse.json({ error: 'Owner permission required.' }, { status: 403 })
  }
  const users = await db.user.findMany({
    orderBy: { createdAt: 'desc' },
    select: {
      id: true,
      role: true,
      createdAt: true,
      _count: { select: { receivedMessages: true } },
    },
  })
  return NextResponse.json({
    users: users.map((u) => ({
      id: u.id,
      role: u.role,
      createdAt: u.createdAt,
      messages: u._count.receivedMessages,
    })),
  })
}
