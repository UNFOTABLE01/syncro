import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'

// Owner only: edit a connected website
export async function PUT(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser(req)
  if (!user || user.role !== 'owner') {
    return NextResponse.json({ error: 'Owner permission required.' }, { status: 403 })
  }
  const { id } = await ctx.params
  try {
    const body = await req.json()
    const name = String(body?.name ?? '').trim()
    let url = String(body?.url ?? '').trim()
    const description = String(body?.description ?? '').trim()

    if (!name || !url) return NextResponse.json({ error: 'Name and URL are required.' }, { status: 400 })
    if (!/^https?:\/\//i.test(url)) url = `https://${url}`
    try {
      new URL(url)
    } catch {
      return NextResponse.json({ error: 'That URL does not look valid.' }, { status: 400 })
    }

    const site = await db.website.update({ where: { id }, data: { name, url, description } })
    return NextResponse.json({ site })
  } catch {
    return NextResponse.json({ error: 'Could not update the website.' }, { status: 500 })
  }
}

// Owner only: remove a website from the network
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const user = await getSessionUser(req)
  if (!user || user.role !== 'owner') {
    return NextResponse.json({ error: 'Owner permission required.' }, { status: 403 })
  }
  const { id } = await ctx.params
  try {
    await db.website.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Could not remove the website.' }, { status: 500 })
  }
}
