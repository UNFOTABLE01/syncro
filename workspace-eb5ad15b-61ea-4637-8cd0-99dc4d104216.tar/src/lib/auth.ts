import crypto from 'crypto'
import type { NextRequest } from 'next/server'
import { db } from '@/lib/db'

const SECRET = process.env.AUTH_SECRET || 'unfotable-local-secret-v1'

export const SESSION_COOKIE = 'unfo_session'
export const ID_MIN = 8
export const ID_MAX = 24

export const ID_PATTERN = /^[A-Za-z0-9]{8,24}$/

/** scrypt hash: "salt:hash" */
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex')
  const hash = crypto.scryptSync(password, salt, 64).toString('hex')
  return `${salt}:${hash}`
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(':')
  if (!salt || !hash) return false
  try {
    const test = crypto.scryptSync(password, salt, 64)
    const orig = Buffer.from(hash, 'hex')
    return crypto.timingSafeEqual(test, orig)
  } catch {
    return false
  }
}

/** Session token: "<userId>.<hmac>" */
export function signSession(userId: string): string {
  const sig = crypto.createHmac('sha256', SECRET).update(userId).digest('hex')
  return `${userId}.${sig}`
}

export function parseSession(token: string | undefined | null): string | null {
  if (!token) return null
  const idx = token.lastIndexOf('.')
  if (idx < 1) return null
  const userId = token.slice(0, idx)
  const sig = token.slice(idx + 1)
  const expected = crypto.createHmac('sha256', SECRET).update(userId).digest('hex')
  try {
    const a = Buffer.from(sig)
    const b = Buffer.from(expected)
    if (a.length !== b.length) return null
    if (!crypto.timingSafeEqual(a, b)) return null
  } catch {
    return null
  }
  return userId
}

/** Returns the logged-in user record, or null. */
export async function getSessionUser(req: NextRequest) {
  const token = req.cookies.get(SESSION_COOKIE)?.value
  const userId = parseSession(token)
  if (!userId) return null
  return db.user.findUnique({ where: { id: userId } })
}

export function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: false,
    path: '/',
    maxAge: 60 * 60 * 24 * 30, // 30 days
  }
}
