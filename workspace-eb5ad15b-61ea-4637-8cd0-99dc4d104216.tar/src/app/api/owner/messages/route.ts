import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'

// Owner only: send a message to one ID or broadcast to every ID
export async function POST(req: NextRequest) {
  const owner = await getSessionUser(req)
  if (!owner || owner.role !== 'owner') {
    return NextResponse.json({ error: 'Owner permission required.' }, { status: 403 })
  }
  try {
    const body = await req.json()
    const to = String(body?.to ?? '').trim() // "all" or a specific ID
    const content = String(body?.content ?? '').trim()

    if (!content) return NextResponse.json({ error: 'Write a message first.' }, { status: 400 })
    if (content.length > 4000) {
      return NextResponse.json({ error: 'Message is too long (max 4000 chars).' }, { status: 400 })
    }

    if (to === 'all') {
      const users = await db.user.findMany({ where: { id: { not: owner.id } }, select: { id: true } })
      if (users.length === 0) {
        return NextResponse.json({ error: 'There are no member IDs yet.' }, { status: 400 })
      }
      await db.message.createMany({
        data: users.map((u) => ({
          toId: u.id,
          fromId: owner.id,
          content,
          broadcast: true,
        })),
      })
      return NextResponse.json({ sent: users.length })
    }

    const target = await db.user.findUnique({ where: { id: to } })
    if (!target) return NextResponse.json({ error: 'That ID does not exist.' }, { status: 404 })

    await db.message.create({
      data: { toId: target.id, fromId: owner.id, content },
    })
    return NextResponse.json({ sent: 1 })
  } catch {
    return NextResponse.json({ error: 'Could not send the message.' }, { status: 500 })
  }
}
