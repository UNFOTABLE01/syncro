/**
 * One-time cleanup: FREE ALL IDs.
 * Deletes every registered user (including the old pre-seeded "Devanshu")
 * and every message. Websites are kept — the network keeps its Splid entry.
 * Afterwards anyone can register any free ID; the ID "Devanshu"
 * (any letter case) automatically gets the owner role at registration.
 */
import { PrismaClient } from '@prisma/client'

const db = new PrismaClient()

async function main() {
  const beforeUsers = await db.user.count()
  const beforeMsgs = await db.message.count()

  await db.message.deleteMany({})
  await db.user.deleteMany({})

  const sites = await db.website.findMany({ select: { name: true, url: true } })
  const afterUsers = await db.user.count()

  console.log(`Freed ${beforeUsers} ID(s) and removed ${beforeMsgs} message(s).`)
  console.log(`IDs remaining: ${afterUsers} — every ID is now free to claim.`)
  console.log(`Websites kept (${sites.length}):`)
  sites.forEach((s) => console.log(`  - ${s.name} → ${s.url}`))
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(() => db.$disconnect())
