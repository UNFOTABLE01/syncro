import type { Metadata } from "next";
import { Inter, Source_Serif_4 } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({
  variable: "--font-inter",
  subsets: ["latin"],
  display: "swap",
});

const sourceSerif = Source_Serif_4({
  variable: "--font-source-serif",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "UNFOTABLE — One ID. Many worlds.",
  description:
    "A connected network of websites. Claim your UNFO ID, sign in from anywhere, and explore every site in the group from one place.",
  keywords: ["UNFOTABLE", "UNFO", "network", "websites", "ID"],
  icons: {
    icon: "/unfo.svg",
  },
  openGraph: {
    title: "UNFOTABLE",
    description: "One ID. Many worlds. A connected group of websites.",
    siteName: "UNFOTABLE",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${sourceSerif.variable} font-sans antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
