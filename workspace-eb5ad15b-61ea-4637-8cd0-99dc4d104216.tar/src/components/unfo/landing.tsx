"use client";

import { useEffect, useRef } from "react";
import { ArrowRight, Globe2, Fingerprint, MousePointerClick, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { getAnime, armVisibilityFallback } from "./anime";
import { Reveal, Counter } from "./reveal";
import { SiteCard } from "./site-card";
import type { Me, Site } from "./types";

function Hero({ sites, onSignIn, onRegister }: { sites: Site[]; onSignIn: () => void; onRegister: () => void }) {
  const ref = useRef<HTMLElement>(null);
  const word = "UNFOTABLE".split("");

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    const disarm = armVisibilityFallback(2400);

    getAnime()
      .then(({ animate, stagger }) => {
        // Soft background blob breathing
        animate(".hero-blob", {
          scale: [1, 1.12, 1],
          opacity: [0.55, 0.8, 0.55],
          duration: 7000,
          loop: true,
          ease: "inOutSine",
        });
        // Pulse dot traveling along the network line
        animate(".pulse-dot", {
          translateX: ["0vw", "calc(100vw - 0px)"],
          duration: 9000,
          loop: true,
          ease: "inOutQuad",
        });
        // Badge
        animate(root.querySelectorAll(".hero-badge"), {
          opacity: [0, 1],
          translateY: [18, 0],
          scale: [0.94, 1],
          duration: 700,
          delay: 120,
          ease: "outBack",
        });
        // The wordmark — letter by letter
        animate(root.querySelectorAll(".hero-letter"), {
          opacity: [0, 1],
          translateY: [76, 0],
          rotate: [6, 0],
          duration: 950,
          delay: stagger(55, { start: 220 }),
          ease: "outExpo",
        });
        // Tagline + CTAs + stats
        animate(root.querySelectorAll(".hero-sub"), {
          opacity: [0, 1],
          translateY: [22, 0],
          duration: 800,
          delay: 820,
          ease: "outCubic",
        });
        animate(root.querySelectorAll(".hero-cta"), {
          opacity: [0, 1],
          translateY: [18, 0],
          duration: 750,
          delay: 1000,
          ease: "outCubic",
        });
        animate(root.querySelectorAll(".hero-stats"), {
          opacity: [0, 1],
          translateY: [14, 0],
          duration: 750,
          delay: 1180,
          ease: "outCubic",
        });
      })
      .catch(() => {
        /* fallback timer reveals everything */
      });

    return disarm;
  }, []);

  return (
    <section ref={ref} className="relative overflow-hidden pt-32 pb-16 sm:pt-40 sm:pb-24">
      {/* backdrop */}
      <div aria-hidden className="unfo-dots absolute inset-0" />
      <div
        aria-hidden
        className="hero-blob absolute -top-40 left-1/2 h-[520px] w-[520px] -translate-x-1/2 rounded-full opacity-60 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(0,0,0,0.12) 0%, rgba(0,0,0,0.07) 45%, transparent 70%)" }}
      />

      <div className="relative mx-auto max-w-6xl px-4 sm:px-6 text-center">
        <div className="hero-badge mx-auto inline-flex items-center gap-2 rounded-full border bg-card/80 backdrop-blur px-4 py-1.5 text-xs font-medium tracking-wide text-muted-foreground shadow-sm">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-primary opacity-60" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-primary" />
          </span>
          THE UNFO NETWORK · LIVE
        </div>

        <h1
          aria-label="UNFOTABLE"
          className="mt-6 font-display font-semibold leading-[0.95] tracking-tight text-foreground text-[15vw] sm:text-7xl md:text-8xl lg:text-[7.5rem] select-none"
        >
          {word.map((ch, i) => (
            <span key={i} aria-hidden className="hero-letter inline-block">
              {ch}
            </span>
          ))}
        </h1>

        <p className="hero-sub mx-auto mt-6 max-w-2xl text-base sm:text-lg leading-relaxed text-muted-foreground">
          One ID. Many worlds. UNFOTABLE ties a whole group of websites into a single
          front door — claim your ID once, and every connected place is one click away.
        </p>

        <div className="hero-cta mt-9 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Button
            size="lg"
            onClick={onRegister}
            className="h-12 rounded-full px-7 text-[15px] font-medium shadow-[0_10px_30px_-10px_rgba(0,0,0,0.5)] transition-transform hover:scale-[1.03] active:scale-[0.98]"
          >
            <Fingerprint className="mr-2 h-4 w-4" />
            Claim your UNFO ID
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={onSignIn}
            className="h-12 rounded-full px-7 text-[15px] font-medium border-[#ddd8cb] bg-card/80 backdrop-blur transition-transform hover:scale-[1.03] active:scale-[0.98]"
          >
            Sign in with your ID
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>

        <div className="hero-stats mx-auto mt-12 grid max-w-md grid-cols-2 gap-3">
          <div className="rounded-2xl border bg-card/80 backdrop-blur px-5 py-4 shadow-sm">
            <div className="font-display text-3xl font-semibold text-foreground">
              <Counter value={sites.length} />
            </div>
            <div className="mt-0.5 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Sites connected
            </div>
          </div>
          <div className="rounded-2xl border bg-card/80 backdrop-blur px-5 py-4 shadow-sm">
            <div className="font-display text-3xl font-semibold text-foreground">8+</div>
            <div className="mt-0.5 text-xs font-medium uppercase tracking-wider text-muted-foreground">
              Characters per ID
            </div>
          </div>
        </div>
      </div>

      {/* network pulse line */}
      <div aria-hidden className="relative mt-14 h-px w-full bg-border/70">
        <div className="pulse-dot absolute -top-[3px] left-0 h-[7px] w-[7px] rounded-full bg-primary shadow-[0_0_12px_2px_rgba(0,0,0,0.45)]" />
      </div>
    </section>
  );
}

const STEPS = [
  {
    icon: Fingerprint,
    title: "Get your UNFO ID",
    body: "Every ID is free to claim. Pick 8 or more letters and digits, pair it with a password, and it is yours — sign back in anytime, from any device.",
  },
  {
    icon: MousePointerClick,
    title: "Step inside the network",
    body: "Your ID works across the whole group. Sign in once and the entire collection of websites opens up from one dashboard.",
  },
  {
    icon: Globe2,
    title: "Watch it grow",
    body: "New websites are curated into the grid by the owner. Every addition appears here live — no re-registering, no new accounts, ever.",
  },
];

function HowItWorks() {
  return (
    <section id="how" className="mx-auto max-w-6xl px-4 sm:px-6 py-20 sm:py-28">
      <Reveal className="text-center">
        <Badge variant="secondary" className="rounded-full px-3 py-1 text-xs font-medium tracking-wide">
          <Sparkles className="mr-1.5 h-3 w-3 text-primary" />
          How UNFOTABLE works
        </Badge>
        <h2 className="mt-4 font-display text-3xl sm:text-4xl font-semibold tracking-tight">
          A tiny internet with one front door
        </h2>
        <p className="mx-auto mt-3 max-w-xl text-sm sm:text-base leading-relaxed text-muted-foreground">
          Three steps. No emails, no spam — just an ID and a password.
        </p>
      </Reveal>

      <div className="mt-12 grid gap-5 md:grid-cols-3">
        {STEPS.map((s, i) => (
          <Reveal key={s.title} delay={i * 120}>
            <div className="group h-full rounded-2xl border bg-card p-6 sm:p-7 shadow-[0_1px_2px_rgba(31,30,26,0.04)] transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_16px_36px_-20px_rgba(31,30,26,0.35)]">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-secondary text-primary transition-colors duration-300 group-hover:bg-primary group-hover:text-white">
                <s.icon className="h-5 w-5" />
              </div>
              <div className="mt-4 text-xs font-semibold uppercase tracking-widest text-primary/80">
                Step {i + 1}
              </div>
              <h3 className="mt-1 font-display text-xl font-semibold tracking-tight">{s.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

function CtaBanner({ onRegister }: { onRegister: () => void }) {
  return (
    <section className="mx-auto max-w-6xl px-4 sm:px-6 pb-24">
      <Reveal>
        <div className="relative overflow-hidden rounded-3xl bg-[#1f1e1a] px-6 py-14 sm:px-14 text-center shadow-[0_30px_60px_-30px_rgba(31,30,26,0.6)]">
          <div
            aria-hidden
            className="absolute -right-24 -top-24 h-72 w-72 rounded-full blur-3xl"
            style={{ background: "radial-gradient(circle, rgba(255,255,255,0.10) 0%, transparent 70%)" }}
          />
          <div
            aria-hidden
            className="absolute -left-24 -bottom-24 h-72 w-72 rounded-full blur-3xl"
            style={{ background: "radial-gradient(circle, rgba(255,255,255,0.06) 0%, transparent 70%)" }}
          />
          <h2 className="relative font-display text-3xl sm:text-4xl font-semibold tracking-tight text-[#faf9f5]">
            Your seat in the network is waiting
          </h2>
          <p className="relative mx-auto mt-3 max-w-lg text-sm sm:text-base text-[#faf9f5]/70">
            Ten seconds to create. Yours to keep. The whole group of websites, always within reach.
          </p>
          <Button
            size="lg"
            onClick={onRegister}
            className="relative mt-8 h-12 rounded-full bg-[#faf9f5] px-8 text-[15px] font-medium text-[#1f1e1a] transition-transform hover:scale-[1.04] hover:bg-white active:scale-[0.98]"
          >
            Create your UNFO ID
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </Reveal>
    </section>
  );
}

export function Landing({
  sites,
  me,
  onSignIn,
  onRegister,
  onOpenDashboard,
}: {
  sites: Site[];
  me: Me | null;
  onSignIn: () => void;
  onRegister: () => void;
  onOpenDashboard: () => void;
}) {
  return (
    <main>
      <Hero sites={sites} onSignIn={onSignIn} onRegister={onRegister} />

      <section id="network" className="mx-auto max-w-6xl px-4 sm:px-6 py-16 sm:py-20">
        <Reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <Badge variant="secondary" className="rounded-full px-3 py-1 text-xs font-medium tracking-wide">
              <Globe2 className="mr-1.5 h-3 w-3 text-primary" />
              The network
            </Badge>
            <h2 className="mt-4 font-display text-3xl sm:text-4xl font-semibold tracking-tight">
              Every website, one grid
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">
            Curated by the owner. Click any card to open that world in a new tab.
          </p>
        </Reveal>

        {sites.length === 0 ? (
          <Reveal className="mt-10">
            <div className="rounded-2xl border border-dashed bg-card/60 p-12 text-center text-sm text-muted-foreground">
              The grid is empty for now — the owner will connect the first websites soon.
            </div>
          </Reveal>
        ) : (
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {sites.map((site, i) => (
              <Reveal key={site.id} delay={(i % 3) * 110}>
                <SiteCard site={site} index={i} />
              </Reveal>
            ))}
          </div>
        )}
      </section>

      <HowItWorks />
      <CtaBanner onRegister={me ? onOpenDashboard : onRegister} />
    </main>
  );
}
