"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import {
  Crown, Globe2, Loader2, Mail, Megaphone, Pencil, Plus, RefreshCw,
  Send, Settings2, Trash2, Users2, X,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { getAnime, fmtAgo, fmtDate } from "./anime";
import { Counter, Reveal } from "./reveal";
import { useToast } from "@/hooks/use-toast";
import type { Me, MemberRow, Portfolio, Site } from "./types";

export function OwnerView({
  me,
  sites,
  onRefreshSites,
}: {
  me: Me;
  sites: Site[];
  onRefreshSites: () => Promise<void>;
}) {
  const [portfolio, setPortfolio] = useState<Portfolio | null>(null);
  const [users, setUsers] = useState<MemberRow[]>([]);
  const [messageTo, setMessageTo] = useState<string | null>(null); // 'all' or an ID
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [messageText, setMessageText] = useState("");
  const [sendBusy, setSendBusy] = useState(false);
  const [deleteBusy, setDeleteBusy] = useState(false);
  const { toast } = useToast();
  const headRef = useRef<HTMLDivElement>(null);

  const loadPortfolio = useCallback(async () => {
    const res = await fetch("/api/owner/stats");
    if (res.ok) setPortfolio(await res.json());
  }, []);

  const loadUsers = useCallback(async () => {
    const res = await fetch("/api/owner/users");
    if (res.ok) {
      const data = await res.json();
      setUsers(data.users ?? []);
    }
  }, []);

  useEffect(() => {
    loadPortfolio();
    loadUsers();
    const iv = setInterval(() => {
      loadPortfolio();
      loadUsers();
    }, 30000);
    return () => clearInterval(iv);
  }, [loadPortfolio, loadUsers]);

  useEffect(() => {
    const root = headRef.current;
    if (!root) return;
    getAnime()
      .then(({ animate, stagger }) => {
        animate(root.querySelectorAll(".own-in"), {
          opacity: [0, 1],
          translateY: [20, 0],
          duration: 700,
          delay: stagger(80),
          ease: "outCubic",
        });
      })
      .catch(() => {
        root.querySelectorAll<HTMLElement>(".own-in").forEach((el) => {
          el.style.opacity = "1";
          el.style.transform = "none";
        });
      });
  }, []);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    if (!messageTo) return;
    setSendBusy(true);
    try {
      const res = await fetch("/api/owner/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ to: messageTo, content: messageText.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Message not sent", description: data?.error, variant: "destructive" });
      } else {
        toast({
          title: messageTo === "all" ? `Broadcast sent to ${data.sent} member${data.sent === 1 ? "" : "s"}` : `Message sent to ${messageTo}`,
        });
        setMessageTo(null);
        setMessageText("");
        loadPortfolio();
      }
    } finally {
      setSendBusy(false);
    }
  }

  async function confirmDelete() {
    if (!deleteId) return;
    setDeleteBusy(true);
    try {
      const res = await fetch(`/api/owner/users/${encodeURIComponent(deleteId)}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Could not remove ID", description: data?.error, variant: "destructive" });
      } else {
        toast({ title: `ID "${deleteId}" removed`, description: "Their messages were cleaned up too." });
        loadUsers();
        loadPortfolio();
      }
    } finally {
      setDeleteBusy(false);
      setDeleteId(null);
    }
  }

  const stats = portfolio?.stats;

  return (
    <main className="mx-auto w-full max-w-6xl flex-1 px-4 sm:px-6 pt-28 pb-20">
      {/* header */}
      <div ref={headRef}>
        <div className="own-in flex flex-wrap items-center gap-2">
          <Badge className="rounded-full bg-[#1f1e1a] px-3 py-1 text-[11px] font-semibold tracking-widest text-[#faf9f5]">
            <Crown className="mr-1 h-3 w-3 text-primary" /> OWNER
          </Badge>
          <Badge variant="secondary" className="rounded-full px-3 py-1 text-[11px] font-medium tracking-wide">
            Full permissions
          </Badge>
        </div>
        <h1 className="own-in mt-3 font-display text-4xl sm:text-5xl font-semibold tracking-tight">
          Owner console
        </h1>
        <p className="own-in mt-2 max-w-xl text-sm sm:text-base leading-relaxed text-muted-foreground">
          Signed in as <span className="font-semibold text-primary">{me.id}</span> — see every ID,
          curate the network, and reach any member directly.
        </p>
      </div>

      {/* stat cards */}
      <div className="own-in mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={Users2} label="Member IDs" value={stats?.members ?? 0} sub="excluding you" />
        <StatCard icon={Globe2} label="Websites" value={stats?.totalSites ?? 0} sub="in the network" />
        <StatCard icon={Mail} label="Messages sent" value={stats?.totalMessages ?? 0} sub="all time" />
        <StatCard icon={Megaphone} label="Unread" value={stats?.unreadMessages ?? 0} sub="awaiting members" />
      </div>

      <Tabs defaultValue="portfolio" className="own-in mt-10">
        <TabsList className="h-11 w-full justify-start overflow-x-auto rounded-2xl bg-secondary p-1 sm:w-auto">
          <TabsTrigger value="portfolio" className="rounded-xl px-4 sm:px-5">Portfolio</TabsTrigger>
          <TabsTrigger value="websites" className="rounded-xl px-4 sm:px-5">Websites</TabsTrigger>
          <TabsTrigger value="members" className="rounded-xl px-4 sm:px-5">Members</TabsTrigger>
          <TabsTrigger value="settings" className="rounded-xl px-4 sm:px-5">Settings</TabsTrigger>
        </TabsList>

        {/* ---------------- PORTFOLIO ---------------- */}
        <TabsContent value="portfolio" className="mt-6 space-y-5">
          <Card className="rounded-2xl border">
            <CardHeader className="pb-2">
              <CardTitle className="font-display text-xl">New IDs — last 14 days</CardTitle>
              <CardDescription>How fast the network is growing.</CardDescription>
            </CardHeader>
            <CardContent>
              {portfolio ? <GrowthChart growth={portfolio.growth} /> : (
                <div className="flex items-center gap-2 py-10 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" /> Loading chart…
                </div>
              )}
            </CardContent>
          </Card>

          <div className="grid gap-5 lg:grid-cols-2">
            <Card className="rounded-2xl border">
              <CardHeader className="pb-2">
                <CardTitle className="font-display text-xl">Network overview</CardTitle>
                <CardDescription>Every connected website.</CardDescription>
              </CardHeader>
              <CardContent>
                {sites.length === 0 ? (
                  <p className="rounded-xl border border-dashed px-4 py-8 text-center text-sm text-muted-foreground">
                    No websites yet — add your first one in the Websites tab.
                  </p>
                ) : (
                  <div className="unfo-scroll max-h-72 space-y-2 overflow-y-auto pr-1">
                    {sites.map((s, i) => (
                      <a
                        key={s.id}
                        href={s.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-3 rounded-xl border bg-card p-3 transition-colors hover:border-primary/40 hover:bg-accent/50"
                      >
                        <span
                          aria-hidden
                          className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg font-display text-sm font-semibold text-white"
                          style={{ background: "linear-gradient(135deg,#3d3d3a,#000000)" }}
                        >
                          {s.name.charAt(0).toUpperCase()}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium">
                            {s.name}
                            <span className="ml-2 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
                              #{i + 1}
                            </span>
                          </span>
                          <span className="block truncate text-xs text-muted-foreground">{s.url}</span>
                        </span>
                        <span className="shrink-0 text-[11px] text-muted-foreground">{fmtDate(s.createdAt)}</span>
                      </a>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="rounded-2xl border">
              <CardHeader className="pb-2">
                <CardTitle className="font-display text-xl">Recent messages</CardTitle>
                <CardDescription>The latest things you sent.</CardDescription>
              </CardHeader>
              <CardContent>
                {!portfolio || portfolio.recentMessages.length === 0 ? (
                  <p className="rounded-xl border border-dashed px-4 py-8 text-center text-sm text-muted-foreground">
                    Nothing sent yet — write to a member from the Members tab.
                  </p>
                ) : (
                  <div className="unfo-scroll max-h-72 space-y-2 overflow-y-auto pr-1">
                    {portfolio.recentMessages.map((m) => (
                      <div key={m.id} className="rounded-xl border bg-card p-3">
                        <div className="flex items-center justify-between gap-2 text-xs">
                          <span className="font-medium">
                            to <span className="text-primary">{m.toId}</span>
                            {m.broadcast && (
                              <Badge variant="secondary" className="ml-2 px-1.5 py-0 text-[9px] uppercase tracking-wider">
                                Broadcast
                              </Badge>
                            )}
                          </span>
                          <span className="text-muted-foreground">{fmtAgo(m.createdAt)}</span>
                        </div>
                        <p className="mt-1.5 line-clamp-2 text-sm text-muted-foreground">{m.content}</p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* ---------------- WEBSITES ---------------- */}
        <TabsContent value="websites" className="mt-6">
          <WebsitesTab sites={sites} onRefreshSites={onRefreshSites} />
        </TabsContent>

        {/* ---------------- MEMBERS ---------------- */}
        <TabsContent value="members" className="mt-6 space-y-5">
          <Card className="rounded-2xl border">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <Megaphone className="h-4 w-4 text-primary" />
                <CardTitle className="font-display text-xl">Broadcast to every member</CardTitle>
              </div>
              <CardDescription>Lands in the inbox of every ID except yours.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                onClick={() => { setMessageTo("all"); setMessageText(""); }}
                className="rounded-xl"
              >
                <Send className="mr-2 h-4 w-4" /> Write a broadcast
              </Button>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <CardTitle className="font-display text-xl">All IDs in UNFOTABLE</CardTitle>
                  <CardDescription className="mt-1">
                    {users.length} ID{users.length === 1 ? "" : "s"} registered — you can message or remove any of them.
                  </CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={loadUsers} aria-label="Refresh members" className="h-8 w-8 p-0">
                  <RefreshCw className="h-3.5 w-3.5" />
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="unfo-scroll max-h-[520px] space-y-2 overflow-y-auto pr-1">
                {users.map((u) => (
                  <div
                    key={u.id}
                    className="flex flex-wrap items-center gap-3 rounded-xl border bg-card p-3.5 transition-colors hover:border-primary/30 sm:flex-nowrap"
                  >
                    <span
                      aria-hidden
                      className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full font-display text-base font-semibold text-white"
                      style={{ background: u.role === "owner" ? "linear-gradient(135deg,#1f1e1a,#56544a)" : "linear-gradient(135deg,#3d3d3a,#000000)" }}
                    >
                      {u.id.charAt(0).toUpperCase()}
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="truncate font-semibold">{u.id}</span>
                        {u.role === "owner" ? (
                          <Badge className="rounded-full bg-[#1f1e1a] px-2 py-0 text-[9px] font-semibold uppercase tracking-widest text-[#faf9f5]">
                            Owner
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="rounded-full px-2 py-0 text-[9px] font-semibold uppercase tracking-widest">
                            Member
                          </Badge>
                        )}
                      </div>
                      <div className="mt-0.5 text-xs text-muted-foreground">
                        Joined {fmtDate(u.createdAt)} · {u.id === me.id ? "—" : `${u.messages} message${u.messages === 1 ? "" : "s"}`}
                      </div>
                    </div>
                    <div className="flex shrink-0 gap-1.5">
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={u.id === me.id}
                        onClick={() => { setMessageTo(u.id); setMessageText(""); }}
                        className="h-8 rounded-lg px-3 text-xs"
                      >
                        <Mail className="mr-1 h-3.5 w-3.5" /> Message
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={u.role === "owner"}
                        onClick={() => setDeleteId(u.id)}
                        className="h-8 rounded-lg px-3 text-xs text-destructive hover:bg-destructive hover:text-white"
                      >
                        <Trash2 className="mr-1 h-3.5 w-3.5" /> Remove
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* ---------------- SETTINGS ---------------- */}
        <TabsContent value="settings" className="mt-6">
          <SettingsTab me={me} />
        </TabsContent>
      </Tabs>

      {/* message dialog (single + broadcast) */}
      <Dialog open={!!messageTo} onOpenChange={(o) => !o && setMessageTo(null)}>
        <DialogContent className="rounded-2xl sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">
              {messageTo === "all" ? "Broadcast to every member" : `Message to ${messageTo}`}
            </DialogTitle>
            <DialogDescription>
              {messageTo === "all"
                ? "Every ID in the network will see this in their inbox."
                : "Only this ID will see it in their inbox."}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={sendMessage} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="msg-content" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Message
              </Label>
              <Textarea
                id="msg-content"
                value={messageText}
                onChange={(e) => setMessageText(e.target.value)}
                placeholder="Something for the network…"
                rows={5}
                className="rounded-xl text-sm"
                maxLength={4000}
              />
              <p className="text-right text-[11px] text-muted-foreground">{messageText.length}/4000</p>
            </div>
            <DialogFooter className="gap-2">
              <Button type="button" variant="outline" onClick={() => setMessageTo(null)} className="rounded-xl">
                Cancel
              </Button>
              <Button type="submit" disabled={sendBusy || !messageText.trim()} className="rounded-xl">
                {sendBusy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
                Send
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* delete confirm */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-2xl">Remove ID “{deleteId}”?</AlertDialogTitle>
            <AlertDialogDescription>
              This deletes the ID permanently and cleans up the messages sent to it. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">Keep it</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); confirmDelete(); }}
              disabled={deleteBusy}
              className="rounded-xl bg-destructive text-white hover:bg-destructive/90"
            >
              {deleteBusy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Remove ID
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </main>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: number;
  sub: string;
}) {
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-[0_1px_2px_rgba(31,30,26,0.04)] transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_14px_30px_-18px_rgba(31,30,26,0.35)]">
      <div className="flex items-center gap-2 text-muted-foreground">
        <Icon className="h-4 w-4 text-primary" />
        <span className="text-xs font-medium uppercase tracking-wider">{label}</span>
      </div>
      <div className="mt-2 font-display text-4xl font-semibold tracking-tight">
        <Counter value={value} />
      </div>
      <div className="mt-1 text-xs text-muted-foreground">{sub}</div>
    </div>
  );
}

function GrowthChart({ growth }: { growth: Portfolio["growth"] }) {
  const ref = useRef<HTMLDivElement>(null);
  const max = Math.max(1, ...growth.map((g) => g.count));

  useEffect(() => {
    const root = ref.current;
    if (!root) return;
    getAnime()
      .then(({ animate, stagger }) => {
        animate(root.querySelectorAll(".growth-bar"), {
          scaleY: [0, 1],
          duration: 900,
          delay: stagger(45),
          ease: "outCubic",
        });
      })
      .catch(() => {
        root.querySelectorAll<HTMLElement>(".growth-bar").forEach((el) => {
          el.style.transform = "none";
        });
      });
  }, [growth]);

  return (
    <div ref={ref}>
      <div className="flex h-44 items-end gap-1.5 sm:gap-2.5">
        {growth.map((g) => (
          <div key={g.date} className="group relative flex h-full flex-1 flex-col justify-end">
            <div
              className="growth-bar w-full"
              style={{ height: `${Math.max(3, (g.count / max) * 100)}%` }}
              title={`${g.date}: ${g.count} new ID${g.count === 1 ? "" : "s"}`}
            />
            <div className="pointer-events-none absolute -top-7 left-1/2 -translate-x-1/2 rounded-md bg-[#1f1e1a] px-2 py-0.5 text-[10px] text-[#faf9f5] opacity-0 transition-opacity group-hover:opacity-100">
              {g.count}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-2 flex gap-1.5 sm:gap-2.5">
        {growth.map((g, i) => (
          <div key={g.date} className={`flex-1 text-center text-[9px] text-muted-foreground ${i % 2 ? "hidden sm:block" : ""}`}>
            {g.date}
          </div>
        ))}
      </div>
    </div>
  );
}

function WebsitesTab({ sites, onRefreshSites }: { sites: Site[]; onRefreshSites: () => Promise<void> }) {
  const [name, setName] = useState("");
  const [url, setUrl] = useState("");
  const [description, setDescription] = useState("");
  const [busy, setBusy] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [edit, setEdit] = useState({ name: "", url: "", description: "" });
  const [removing, setRemoving] = useState<Site | null>(null);
  const [removeBusy, setRemoveBusy] = useState(false);
  const { toast } = useToast();

  async function addSite(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await fetch("/api/sites", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, url, description }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Could not add website", description: data?.error, variant: "destructive" });
      } else {
        toast({ title: `${data.site.name} is live`, description: "It appears on the public grid instantly." });
        setName("");
        setUrl("");
        setDescription("");
        await onRefreshSites();
      }
    } finally {
      setBusy(false);
    }
  }

  function startEdit(s: Site) {
    setEditId(s.id);
    setEdit({ name: s.name, url: s.url, description: s.description });
  }

  async function saveEdit() {
    if (!editId) return;
    const res = await fetch(`/api/sites/${editId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(edit),
    });
    const data = await res.json();
    if (!res.ok) {
      toast({ title: "Could not save", description: data?.error, variant: "destructive" });
    } else {
      toast({ title: "Website updated", description: "The public grid reflects it immediately." });
      setEditId(null);
      await onRefreshSites();
    }
  }

  async function removeSite() {
    if (!removing) return;
    setRemoveBusy(true);
    try {
      const res = await fetch(`/api/sites/${removing.id}`, { method: "DELETE" });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Could not remove", description: data?.error, variant: "destructive" });
      } else {
        toast({ title: `${removing.name} removed from the network` });
        await onRefreshSites();
      }
    } finally {
      setRemoveBusy(false);
      setRemoving(null);
    }
  }

  return (
    <div className="space-y-5">
      <Card className="rounded-2xl border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Plus className="h-4 w-4 text-primary" />
            <CardTitle className="font-display text-xl">Connect a website</CardTitle>
          </div>
          <CardDescription>
            Add any link to the public grid — it goes live instantly. This is how the network grows.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={addSite} className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5">
              <Label htmlFor="site-name" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Name</Label>
              <Input id="site-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Splid" className="h-10 rounded-xl text-sm" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="site-url" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">URL</Label>
              <Input id="site-url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://…" className="h-10 rounded-xl text-sm" />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="site-desc" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">Short description (optional)</Label>
              <Input id="site-desc" value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What is this website about?" className="h-10 rounded-xl text-sm" />
            </div>
            <div className="sm:col-span-2">
              <Button type="submit" disabled={busy || !name.trim() || !url.trim()} className="h-10 rounded-xl">
                {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Plus className="mr-2 h-4 w-4" />}
                Add to the network
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Globe2 className="h-4 w-4 text-primary" />
            <CardTitle className="font-display text-xl">Connected websites</CardTitle>
            <Badge variant="secondary" className="rounded-full px-2 py-0 text-[10px]">{sites.length}</Badge>
          </div>
          <CardDescription>Edit or remove any card — changes are live everywhere.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {sites.length === 0 && (
            <p className="rounded-xl border border-dashed px-4 py-8 text-center text-sm text-muted-foreground">
              Nothing connected yet — add your first website above.
            </p>
          )}
          {sites.map((s) =>
            editId === s.id ? (
              <div key={s.id} className="rounded-xl border border-primary/40 bg-accent/40 p-4">
                <div className="grid gap-2.5 sm:grid-cols-2">
                  <Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} placeholder="Name" className="h-10 rounded-xl text-sm" />
                  <Input value={edit.url} onChange={(e) => setEdit({ ...edit, url: e.target.value })} placeholder="URL" className="h-10 rounded-xl text-sm" />
                  <Input value={edit.description} onChange={(e) => setEdit({ ...edit, description: e.target.value })} placeholder="Description" className="h-10 rounded-xl text-sm sm:col-span-2" />
                </div>
                <div className="mt-3 flex gap-2">
                  <Button size="sm" onClick={saveEdit} className="h-9 rounded-lg px-4 text-xs">Save changes</Button>
                  <Button size="sm" variant="outline" onClick={() => setEditId(null)} className="h-9 rounded-lg px-4 text-xs">
                    <X className="mr-1 h-3 w-3" /> Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div key={s.id} className="flex flex-wrap items-center gap-3 rounded-xl border bg-card p-3.5 transition-colors hover:border-primary/30 sm:flex-nowrap">
                <span
                  aria-hidden
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg font-display text-base font-semibold text-white"
                  style={{ background: "linear-gradient(135deg,#3d3d3a,#000000)" }}
                >
                  {s.name.charAt(0).toUpperCase()}
                </span>
                <div className="min-w-0 flex-1">
                  <div className="truncate font-semibold">{s.name}</div>
                  <a href={s.url} target="_blank" rel="noopener noreferrer" className="block truncate text-xs text-primary hover:underline">
                    {s.url}
                  </a>
                  {s.description && <p className="mt-0.5 truncate text-xs text-muted-foreground">{s.description}</p>}
                </div>
                <div className="flex shrink-0 gap-1.5">
                  <Button size="sm" variant="outline" onClick={() => startEdit(s)} className="h-8 rounded-lg px-3 text-xs">
                    <Pencil className="mr-1 h-3 w-3" /> Edit
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setRemoving(s)}
                    className="h-8 rounded-lg px-3 text-xs text-destructive hover:bg-destructive hover:text-white"
                  >
                    <Trash2 className="mr-1 h-3 w-3" /> Remove
                  </Button>
                </div>
              </div>
            )
          )}
        </CardContent>
      </Card>

      <AlertDialog open={!!removing} onOpenChange={(o) => !o && setRemoving(null)}>
        <AlertDialogContent className="rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-display text-2xl">Remove “{removing?.name}”?</AlertDialogTitle>
            <AlertDialogDescription>
              It disappears from the public grid right away. You can always connect it again later.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-xl">Keep it</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); removeSite(); }}
              disabled={removeBusy}
              className="rounded-xl bg-destructive text-white hover:bg-destructive/90"
            >
              {removeBusy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

function SettingsTab({ me }: { me: Me }) {
  const [currentPw, setCurrentPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [busy, setBusy] = useState(false);
  const { toast } = useToast();

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await fetch("/api/auth/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: currentPw, newPassword: newPw }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "Could not change password", description: data?.error, variant: "destructive" });
      } else {
        toast({ title: "Password updated", description: "Use the new one next time." });
        setCurrentPw("");
        setNewPw("");
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card className="rounded-2xl border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Settings2 className="h-4 w-4 text-primary" />
            <CardTitle className="font-display text-xl">Owner password</CardTitle>
          </div>
          <CardDescription>
            Keep the owner ID <span className="font-semibold text-foreground">{me.id}</span> safe — it holds full permissions over UNFOTABLE.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={changePassword} className="space-y-2.5">
            <Input
              type="password"
              value={currentPw}
              onChange={(e) => setCurrentPw(e.target.value)}
              placeholder="Current password"
              autoComplete="current-password"
              className="h-10 rounded-xl text-sm"
            />
            <Input
              type="password"
              value={newPw}
              onChange={(e) => setNewPw(e.target.value)}
              placeholder="New password (4+ characters)"
              autoComplete="new-password"
              className="h-10 rounded-xl text-sm"
            />
            <Button type="submit" disabled={busy} className="h-10 rounded-xl">
              {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Update password
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="rounded-2xl border">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <Crown className="h-4 w-4 text-primary" />
            <CardTitle className="font-display text-xl">Owner powers</CardTitle>
          </div>
          <CardDescription>What this ID can do across UNFOTABLE.</CardDescription>
        </CardHeader>
        <CardContent>
          <Reveal>
            <ul className="space-y-2.5 text-sm">
              {[
                "See every ID registered in the network",
                "Remove any member ID at any time",
                "Message one ID or broadcast to all of them",
                "Connect, edit, and remove websites on the public grid",
                "Watch the full portfolio: growth, sites, and messages",
              ].map((p) => (
                <li key={p} className="flex items-start gap-2.5 rounded-lg bg-secondary/60 px-3.5 py-2.5">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                  {p}
                </li>
              ))}
            </ul>
          </Reveal>
        </CardContent>
      </Card>
    </div>
  );
}
