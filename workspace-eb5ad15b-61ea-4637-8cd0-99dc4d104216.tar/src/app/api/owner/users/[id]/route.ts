import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionUser } from '@/lib/auth'

// Owner only: remove an ID from UNFOTABLE (their messages go with them)
export async function DELETE(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const owner = await getSessionUser(req)
  if (!owner || owner.role !== 'owner') {
    return NextResponse.json({ error: 'Owner permission required.' }, { status: 403 })
  }
  const { id } = await ctx.params
  if (id === owner.id) {
    return NextResponse.json({ error: 'The owner ID cannot be removed.' }, { status: 400 })
  }
  try {
    const target = await db.user.findUnique({ where: { id } })
    if (!target) return NextResponse.json({ error: 'ID not found.' }, { status: 404 })
    if (target.role === 'owner') {
      return NextResponse.json({ error: 'The owner ID cannot be removed.' }, { status: 400 })
    }
    await db.user.delete({ where: { id } })
    return NextResponse.json({ ok: true })
  } catch {
    return NextResponse.json({ error: 'Could not remove that ID.' }, { status: 500 })
  }
}
