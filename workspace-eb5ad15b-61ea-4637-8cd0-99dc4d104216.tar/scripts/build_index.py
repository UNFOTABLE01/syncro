#!/usr/bin/env python3
"""Assemble the standalone UNFOTABLE index.html (inlines anime.js UMD + app parts)."""
import pathlib

ROOT = pathlib.Path("/home/z/my-project")
p1 = (ROOT / "scripts/unfo_p1.html").read_text(encoding="utf-8")
p2 = (ROOT / "scripts/unfo_p2.js").read_text(encoding="utf-8")
p3 = (ROOT / "scripts/unfo_p3.js").read_text(encoding="utf-8")
umd = (ROOT / "node_modules/animejs/dist/bundles/anime.umd.min.js").read_text(encoding="utf-8")

# Safety: nothing inlined may close the host <script> tag early
for name, blob in (("umd", umd), ("p2", p2), ("p3", p3)):
    assert "</script" not in blob.lower(), f"{name} contains a closing </script> sequence!"

assert "/*__APP_B__*/" in p2, "p2 is missing the APP_B marker!"
assert "/*__ANIME_UMD__*/" in p1, "p1 is missing the ANIME_UMD marker!"

app_js = p2.replace("/*__APP_B__*/", p3)
out = p1.replace("/*__ANIME_UMD__*/", umd).replace("/*__APP_A__*/", app_js)
out = out.replace("<script>/*__APP_B__*/</script>", "")  # strip leftover marker tag

# The APP_A marker sat on its own line; app_js replaces it inline — verify structure
assert "function init()" in out and "runPublicAnims" in out and "OwnerView" in out

dest = ROOT / "download/index.html"
dest.parent.mkdir(parents=True, exist_ok=True)
dest.write_text(out, encoding="utf-8")
print(f"OK -> {dest} ({dest.stat().st_size/1024:.1f} KB)")
print("anime.js inlined:", "anime.umd.min.js" in umd[:0] or len(umd) > 100000)
print("has Devanshu seed:", "Devanshu" in out)
print("has Splid seed:", "splid.unfo.workers.dev" in out)
