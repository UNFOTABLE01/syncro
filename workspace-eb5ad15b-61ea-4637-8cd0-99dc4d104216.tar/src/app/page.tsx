"use client";

import { useCallback, useEffect, useState } from "react";
import { LogOut, LayoutDashboard } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Landing } from "@/components/unfo/landing";
import { AuthView } from "@/components/unfo/auth-view";
import { UserView } from "@/components/unfo/user-view";
import { OwnerView } from "@/components/unfo/owner-view";
import { FadeIn } from "@/components/unfo/reveal";
import type { Me, Site } from "@/components/unfo/types";

type Screen = "public" | "auth" | "dash";

export default function Home() {
  const [me, setMe] = useState<Me | null | undefined>(undefined); // undefined = loading
  const [screen, setScreen] = useState<Screen>("public");
  const [authTab, setAuthTab] = useState<"login" | "register">("login");
  const [sites, setSites] = useState<Site[]>([]);
  const { toast } = useToast();

  const loadSites = useCallback(async () => {
    try {
      const res = await fetch("/api/sites");
      const data = await res.json();
      setSites(data.sites ?? []);
    } catch {
      /* keep previous list */
    }
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const [meRes] = await Promise.all([
          fetch("/api/auth/me"),
          loadSites(),
        ]);
        const data = await meRes.json();
        setMe(data.user ?? null);
      } catch {
        setMe(null);
      }
    })();
  }, [loadSites]);

  function handleAuthed(user: Me) {
    setMe(user);
    setScreen("dash");
    toast({
      title: `Signed in as ${user.id}`,
      description:
        user.role === "owner"
          ? "Welcome back — the owner console is ready."
          : "Welcome to UNFOTABLE.",
    });
  }

  async function signOut() {
    await fetch("/api/auth/logout", { method: "POST" });
    setMe(null);
    setScreen("public");
    toast({ title: "Signed out", description: "Your ID will be here when you come back." });
  }

  const isOwner = me?.role === "owner";

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* ---------------- header ---------------- */}
      <header className="fixed inset-x-0 top-0 z-50 border-b border-border/60 bg-[#faf9f5]/85 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <button
            onClick={() => setScreen("public")}
            className="group flex items-center gap-2.5 focus-visible:outline-none"
            aria-label="UNFOTABLE home"
          >
            <span
              aria-hidden
              className="flex h-8 w-8 items-center justify-center rounded-xl font-display text-base font-semibold text-white shadow-[0_6px_16px_-6px_rgba(0,0,0,0.55)] transition-transform duration-300 group-hover:rotate-6 group-hover:scale-105"
              style={{ background: "linear-gradient(135deg,#2e2e2b,#000000)" }}
            >
              U
            </span>
            <span className="font-display text-lg font-semibold tracking-tight">
              UNFOTABLE
              <span className="text-primary">.</span>
            </span>
          </button>

          <div className="flex items-center gap-2">
            {me === undefined ? null : me === null ? (
              <>
                <Button
                  variant="ghost"
                  onClick={() => { setAuthTab("login"); setScreen("auth"); }}
                  className="h-9 rounded-full px-4 text-sm"
                >
                  Sign in
                </Button>
                <Button
                  onClick={() => { setAuthTab("register"); setScreen("auth"); }}
                  className="h-9 rounded-full px-4 text-sm shadow-[0_8px_20px_-8px_rgba(0,0,0,0.5)]"
                >
                  Create ID
                </Button>
              </>
            ) : (
              <>
                <Badge variant="secondary" className="hidden rounded-full px-3 py-1 text-xs font-medium sm:inline-flex">
                  {me.id}
                  {isOwner && <span className="ml-1.5 text-primary">· OWNER</span>}
                </Badge>
                {screen !== "dash" && (
                  <Button onClick={() => setScreen("dash")} className="h-9 rounded-full px-4 text-sm">
                    <LayoutDashboard className="mr-1.5 h-4 w-4" />
                    {isOwner ? "Owner console" : "Dashboard"}
                  </Button>
                )}
                <Button
                  variant="outline"
                  onClick={signOut}
                  aria-label="Sign out"
                  className="h-9 rounded-full border-[#ddd8cb] px-3 text-sm"
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </>
            )}
          </div>
        </div>
      </header>

      {/* ---------------- body ---------------- */}
      {me === undefined ? (
        <div className="flex min-h-screen items-center justify-center">
          <div
            aria-hidden
            className="flex h-12 w-12 items-center justify-center rounded-2xl font-display text-xl font-semibold text-white"
            style={{ background: "linear-gradient(135deg,#2e2e2b,#000000)" }}
          >
            U
          </div>
        </div>
      ) : screen === "auth" ? (
        <FadeIn>
          <AuthView
            key={authTab}
            initialTab={authTab}
            onAuthed={handleAuthed}
            onBack={() => setScreen("public")}
          />
        </FadeIn>
      ) : screen === "dash" && me ? (
        <FadeIn key={me.id}>
          {isOwner ? (
            <OwnerView me={me} sites={sites} onRefreshSites={loadSites} />
          ) : (
            <UserView me={me} sites={sites} onRefreshSites={loadSites} />
          )}
        </FadeIn>
      ) : (
        <FadeIn key="landing">
          <Landing
            sites={sites}
            me={me}
            onSignIn={() => { setAuthTab("login"); setScreen("auth"); }}
            onRegister={() => { setAuthTab("register"); setScreen("auth"); }}
            onOpenDashboard={() => setScreen("dash")}
          />
        </FadeIn>
      )}

      {/* ---------------- footer ---------------- */}
      <footer className="mt-auto bg-[#1f1e1a] text-[#faf9f5]/85">
        <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
          <div className="flex flex-wrap items-start justify-between gap-8">
            <div>
              <div className="flex items-center gap-2.5">
                <span
                  aria-hidden
                  className="flex h-8 w-8 items-center justify-center rounded-xl font-display text-base font-semibold text-white"
                  style={{ background: "linear-gradient(135deg,#2e2e2b,#000000)" }}
                >
                  U
                </span>
                <span className="font-display text-xl font-semibold tracking-tight text-[#faf9f5]">
                  UNFOTABLE<span className="text-primary">.</span>
                </span>
              </div>
              <p className="mt-3 max-w-xs text-sm leading-relaxed text-[#faf9f5]/60">
                One ID. Many worlds. A simple, growing group of websites with a single front door.
              </p>
            </div>
            <div className="text-sm text-[#faf9f5]/60">
              <div className="font-medium text-[#faf9f5]/90">Network</div>
              <ul className="mt-2 space-y-1.5">
                <li>
                  <button onClick={() => setScreen("public")} className="transition-colors hover:text-primary">
                    Home
                  </button>
                </li>
                <li>
                  <button
                    onClick={() =>
                      me ? setScreen("dash") : (setAuthTab("login"), setScreen("auth"))
                    }
                    className="transition-colors hover:text-primary"
                  >
                    {me ? (isOwner ? "Owner console" : "Dashboard") : "Sign in"}
                  </button>
                </li>
                <li>
                  <a
                    href="https://splid.unfo.workers.dev/"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="transition-colors hover:text-primary"
                  >
                    Splid ↗
                  </a>
                </li>
              </ul>
            </div>
            <div className="text-sm text-[#faf9f5]/60">
              <div className="font-medium text-[#faf9f5]/90">Curated by</div>
              <p className="mt-2">
                <span className="font-semibold text-primary">Devanshu</span>
                <br />
                Owner of the UNFO network
              </p>
            </div>
          </div>
          <div className="mt-10 flex flex-wrap items-center justify-between gap-3 border-t border-[#faf9f5]/10 pt-6 text-xs text-[#faf9f5]/45">
            <span>© {new Date().getFullYear()} UNFOTABLE · All worlds reserved</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
