import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { hashPassword, signSession, cookieOptions, SESSION_COOKIE, ID_PATTERN } from '@/lib/auth'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const rawId = String(body?.id ?? '').trim()
    const password = String(body?.password ?? '')

    if (!ID_PATTERN.test(rawId)) {
      return NextResponse.json(
        { error: 'ID must be 8–24 characters, letters and digits only.' },
        { status: 400 }
      )
    }
    if (password.length < 4) {
      return NextResponse.json({ error: 'Password must be at least 4 characters.' }, { status: 400 })
    }

    // case-insensitive uniqueness check
    const all = await db.user.findMany({ where: { id: { in: [rawId] } }, select: { id: true } })
    const exact = all.some((u) => u.id === rawId)
    if (exact) {
      return NextResponse.json({ error: 'That ID is already taken. Try another one.' }, { status: 409 })
    }
    const lowerAll = await db.user.findMany({ select: { id: true } })
    if (lowerAll.some((u) => u.id.toLowerCase() === rawId.toLowerCase())) {
      return NextResponse.json({ error: 'That ID is already taken. Try another one.' }, { status: 409 })
    }

    // Every ID is free to claim. The ID "Devanshu" (any letter case)
    // carries full owner permissions for whoever claims it.
    const isOwner = rawId.toLowerCase() === 'devanshu'
    const user = await db.user.create({
      data: { id: rawId, password: hashPassword(password), role: isOwner ? 'owner' : 'user' },
    })

    const res = NextResponse.json({ user: { id: user.id, role: user.role, createdAt: user.createdAt } })
    res.cookies.set(SESSION_COOKIE, signSession(user.id), cookieOptions())
    return res
  } catch {
    return NextResponse.json({ error: 'Could not create the ID. Try again.' }, { status: 500 })
  }
}
