"use client";

/**
 * anime.js v4 helpers.
 * Everything is loaded lazily inside effects (browser only),
 * with a visibility fallback so content never stays hidden.
 */

export async function getAnime() {
  return import("animejs");
}

/** Force any entrance-animation targets visible (safety net). */
export function forceVisible(root: Document | ParentNode | null = document) {
  if (!root) return;
  const els = root.querySelectorAll<HTMLElement>(".hero-anim, .will-animate, .will-animate-rise");
  els.forEach((el) => {
    el.style.opacity = "1";
    el.style.transform = "none";
  });
}

/** After this long, any hidden entrance element is revealed regardless. */
export function armVisibilityFallback(delayMs = 2200) {
  const t = setTimeout(() => forceVisible(document), delayMs);
  return () => clearTimeout(t);
}

export function hostnameOf(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return url;
  }
}

export function fmtDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    });
  } catch {
    return iso;
  }
}

export function fmtAgo(iso: string): string {
  try {
    const diff = Date.now() - new Date(iso).getTime();
    const m = Math.floor(diff / 60000);
    if (m < 1) return "just now";
    if (m < 60) return `${m}m ago`;
    const h = Math.floor(m / 60);
    if (h < 24) return `${h}h ago`;
    const d = Math.floor(h / 24);
    if (d < 30) return `${d}d ago`;
    return fmtDate(iso);
  } catch {
    return iso;
  }
}
