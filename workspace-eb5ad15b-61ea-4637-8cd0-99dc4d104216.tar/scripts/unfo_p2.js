(() => {
"use strict";

/* ================= helpers ================= */
const $  = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = s => String(s == null ? "" : s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
const dayKey = ts => { const d = new Date(ts); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); };
const fmtDay = ts => new Date(ts).toLocaleDateString(undefined, { month: "short", day: "2-digit" });
const fmtFull = ts => new Date(ts).toLocaleDateString(undefined, { month: "short", day: "2-digit", year: "numeric" });
const hostOf = u => { try { return new URL(u).hostname.replace(/^www\./, ""); } catch (e) { return String(u || ""); } };

/* ================= toasts ================= */
function toast(title, desc) {
  const wrap = $("#toasts");
  if (!wrap) return;
  const t = document.createElement("div");
  t.className = "toast";
  t.innerHTML = '<div class="toast-title">' + esc(title) + "</div>" + (desc ? '<div class="toast-desc">' + esc(desc) + "</div>" : "");
  wrap.appendChild(t);
  requestAnimationFrame(() => t.classList.add("show"));
  setTimeout(() => { t.classList.remove("show"); setTimeout(() => t.remove(), 320); }, 3400);
}

/* ================= modal confirm ================= */
let modalCb = null;
function confirmBox(title, body, okLabel, cb) {
  $("#modal-title").textContent = title;
  $("#modal-body").textContent = body;
  $("#modal-ok").textContent = okLabel || "Confirm";
  modalCb = cb;
  $("#modal-mask").classList.add("open");
}

/* ================= storage / db ================= */
const K = { users: "unfo_users", sites: "unfo_sites", msgs: "unfo_msgs", sess: "unfo_sess", ver: "unfo_db_ver" };
/* DB v2: ALL IDs are free — no account is pre-registered. Whoever claims
   the ID "Devanshu" (any letter case) gets the owner role automatically. */
const DB_VER = 2;
const read = (k, f) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? f : v; } catch (e) { return f; } };
const write = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };

async function hashPw(pw, salt) {
  const text = salt + "::" + pw;
  if (window.crypto && crypto.subtle && crypto.subtle.digest) {
    try {
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
      return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, "0")).join("");
    } catch (e) { /* fall through */ }
  }
  let h1 = 0xdeadbeef, h2 = 0x41c6ce57;
  for (let i = 0; i < text.length; i++) {
    const c = text.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 2654435761);
    h2 = Math.imul(h2 ^ c, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (h2 >>> 0).toString(16).padStart(8, "0") + (h1 >>> 0).toString(16).padStart(8, "0");
}

const validId = id => /^[A-Za-z0-9]{8,24}$/.test(id);

async function seed() {
  const ver = Number(read(K.ver, 0));
  if (ver === DB_VER && localStorage.getItem(K.users)) return;
  /* v1 → v2 migration: free every pre-registered ID (old builds seeded an
     owner account that made "Devanshu" appear taken). Fresh start: zero
     accounts, the Splid website only. */
  const now = Date.now();
  write(K.users, []);
  write(K.sites, [{
    id: "splid",
    name: "Splid",
    url: "https://splid.unfo.workers.dev/",
    description: "The first member of the UNFOTABLE network — a live app running on Cloudflare Workers.",
    createdAt: now - 14 * 864e5
  }]);
  write(K.msgs, []);
  localStorage.removeItem(K.sess);
  write(K.ver, DB_VER);
}

const allUsers = () => read(K.users, []);
const allSites = () => read(K.sites, []).slice().sort((a, b) => a.createdAt - b.createdAt);
const allMsgs  = () => read(K.msgs, []);
const me = () => {
  const id = read(K.sess, null);
  return id ? (allUsers().find(u => u.id === id) || null) : null;
};
const saveUsers = u => write(K.users, u);
const saveSites = s => write(K.sites, s);
const saveMsgs  = m => write(K.msgs, m);

/* ================= anime.js glue ================= */
const AN = window.anime || null;
const canAnime = !!(AN && typeof AN.animate === "function");
const stg = canAnime && AN.stagger ? AN.stagger : null;
function an(targets, params) {
  if (canAnime) {
    try { AN.animate(targets, params); } catch (e) { hardShow(targets); }
  } else {
    hardShow(targets);
  }
}
function hardShow(targets) {
  let els = [];
  try { els = typeof targets === "string" ? $$(targets) : Array.prototype.slice.call(targets.nodeType ? [targets] : (targets || [])); } catch (e) {}
  els.forEach(el => {
    el.style.opacity = "1";
    el.style.transform = "none";
  });
}
function safetyShow(root) {
  setTimeout(() => {
    $$(".a-h, .a-rise, .rv, .hero-title span", root || document).forEach(el => {
      if (!el.classList.contains("rv")) { el.style.opacity = "1"; el.style.transform = "none"; }
    });
  }, 2600);
}

/* ================= state ================= */
let screen = "public";
let authTab = "login";
let dashTab = "portfolio";
let editingSiteId = null;
let msgTargetId = null;
let inboxTimer = null;

function stopTimers() { if (inboxTimer) { clearInterval(inboxTimer); inboxTimer = null; } }

/* ================= header ================= */
function renderHeader(u) {
  const box = $("#hd-actions");
  if (u === undefined) { box.innerHTML = ""; return; }
  if (!u) {
    box.innerHTML =
      '<button class="btn btn-ghost" onclick="A.openAuth(\'login\')">Sign in</button>' +
      '<button class="btn btn-primary" onclick="A.openAuth(\'register\')">Create ID</button>';
  } else {
    const isOwner = u.role === "owner";
    box.innerHTML =
      '<span class="badge" style="font-size:12.5px">' + esc(u.id) +
      (isOwner ? ' <span class="owner-tag">· OWNER</span>' : "") + "</span>" +
      (screen !== "dash"
        ? '<button class="btn btn-primary" onclick="A.go(\'dash\')">' + (isOwner ? "Owner console" : "Dashboard") + "</button>"
        : "") +
      '<button class="btn btn-outline btn-icon" title="Sign out" aria-label="Sign out" onclick="A.signOut()">⎋</button>';
  }
}

/* ================= public view ================= */
const HERO_WORD = "UNFOTABLE";
const TILES = [
  "linear-gradient(135deg, #1c1c1a 0%, #000000 100%)",
  "linear-gradient(135deg, #4a4a47 0%, #1c1c1a 100%)",
  "linear-gradient(135deg, #8a8778 0%, #56544a 100%)",
  "linear-gradient(135deg, #33332f 0%, #0f0f0e 100%)"
];
const tileOf = i => TILES[i % TILES.length];

function siteCardHTML(s, i) {
  return (
    '<a class="site-card" href="' + esc(s.url) + '" target="_blank" rel="noopener noreferrer" aria-label="Visit ' + esc(s.name) + '">' +
      '<div class="site-card-top">' +
        '<div class="tile serif" style="background:' + tileOf(i) + '">' + esc((s.name || "?").charAt(0).toUpperCase()) + "</div>" +
        '<span class="go-ring">↗</span>' +
      "</div>" +
      '<h3 class="site-name serif">' + esc(s.name) + "</h3>" +
      '<p class="site-desc">' + esc(s.description || "A member of the UNFOTABLE network.") + "</p>" +
      '<div class="site-foot">' +
        '<span class="badge host-badge">' + esc(hostOf(s.url)) + "</span>" +
        '<span class="visit-hint">Visit site</span>' +
      "</div>" +
    "</a>"
  );
}

function PublicView(u) {
  const list = allSites();
  const letters = HERO_WORD.split("").map(ch => '<span aria-hidden="true">' + esc(ch) + "</span>").join("");
  return (
  '<section class="hero">' +
    '<div class="dots" aria-hidden="true"></div>' +
    '<div class="glow a-h" aria-hidden="true"></div>' +
    '<div class="wrap" style="position:relative">' +
      '<div class="hero-badge a-h"><span class="live-dot"></span>THE UNFO NETWORK · LIVE</div>' +
      '<h1 class="hero-title serif" aria-label="UNFOTABLE">' + letters + "</h1>" +
      '<p class="hero-sub a-rise">One ID. Many worlds. UNFOTABLE ties a whole group of websites into a single front door — claim your ID once, and every connected place is one click away.</p>' +
      '<div class="hero-cta a-rise">' +
        (u ? '<button class="btn btn-primary btn-lg" onclick="A.go(\'dash\')">Open your dashboard →</button>' +
             '<button class="btn btn-outline btn-lg" onclick="A.scrollGrid()">See the network</button>'
           : '<button class="btn btn-primary btn-lg" onclick="A.openAuth(\'register\')">Claim your UNFO ID</button>' +
             '<button class="btn btn-outline btn-lg" onclick="A.openAuth(\'login\')">Sign in with your ID →</button>') +
      "</div>" +
      '<div class="hero-stats a-rise">' +
        '<div class="stat-box"><div class="stat-num serif" id="stat-sites">0</div><div class="stat-label">Sites connected</div></div>' +
        '<div class="stat-box"><div class="stat-num serif">8+</div><div class="stat-label">Characters per ID</div></div>' +
      "</div>" +
    "</div>" +
    '<div class="pulse-line" aria-hidden="true"><span class="pulse-dot"></span></div>' +
  "</section>" +

  '<section class="section" id="network-grid">' +
    '<div class="wrap">' +
      '<div class="rv" style="display:flex;flex-wrap:wrap;align-items:flex-end;justify-content:space-between;gap:16px">' +
        "<div>" +
          '<span class="sec-badge">🌐 The network</span>' +
          '<h2 class="sec-title serif">Every website, one grid</h2>' +
        "</div>" +
        '<p style="max-width:380px;color:var(--muted);font-size:14.5px">Curated by the owner. Click any card to open that world in a new tab.</p>' +
      "</div>" +
      '<div class="site-grid">' +
        (list.length
          ? list.map((s, i) => '<div class="rv">' + siteCardHTML(s, i) + "</div>").join("")
          : '<div class="empty rv" style="grid-column:1/-1">No websites in the network yet — the owner will curate them soon.</div>') +
      "</div>" +
    "</div>" +
  "</section>" +

  '<section class="section" style="padding-top:0" id="how">' +
    '<div class="wrap">' +
      '<div class="rv" style="text-align:center">' +
        '<span class="sec-badge">✦ How UNFOTABLE works</span>' +
        '<h2 class="sec-title serif">A tiny internet with one front door</h2>' +
        '<p class="sec-sub">Three steps. No emails, no spam — just an ID and a password.</p>' +
      "</div>" +
      '<div class="grid grid-3">' +
        [
          ["☝", "Get your UNFO ID", "Every ID is free to claim. Pick 8 or more letters and digits, pair it with a password, and it is yours — sign back in anytime, from any device."],
          ["🖱", "Step inside the network", "Your ID works across the whole group. Sign in once and the entire collection of websites opens up from one dashboard."],
          ["🌍", "Watch it grow", "New websites are curated into the grid by the owner. Every addition appears here live — no re-registering, no new accounts, ever."]
        ].map((s, i) =>
          '<div class="rv"><div class="step-card">' +
            '<div class="step-icon">' + s[0] + "</div>" +
            '<div class="step-kicker">Step ' + (i + 1) + "</div>" +
            '<h3 class="step-title serif">' + s[1] + "</h3>" +
            '<p class="step-body">' + s[2] + "</p>" +
          "</div></div>"
        ).join("") +
      "</div>" +
    "</div>" +
  "</section>" +

  '<section style="padding-bottom:96px">' +
    '<div class="wrap">' +
      '<div class="cta-banner rv">' +
        '<div class="cta-glow" style="background:radial-gradient(circle, rgba(255,255,255,.10) 0%, transparent 70%);right:-96px;top:-96px"></div>' +
        '<div class="cta-glow" style="background:radial-gradient(circle, rgba(255,255,255,.06) 0%, transparent 70%);left:-96px;bottom:-96px"></div>' +
        '<h2 class="cta-title serif">Your seat in the network is waiting</h2>' +
        '<p class="cta-sub">Ten seconds to create. Yours to keep. The whole group of websites, always within reach.</p>' +
        '<button class="btn btn-white btn-lg" style="margin-top:30px" onclick="A.openAuth(\'register\')">Create your UNFO ID →</button>' +
      "</div>" +
    "</div>" +
  "</section>"
  );
}

function countUp(elm, target) {
  const t0 = performance.now(), dur = 1100;
  function step(now) {
    const p = Math.min(1, (now - t0) / dur);
    elm.textContent = String(Math.round(target * (1 - Math.pow(1 - p, 3))));
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

function runPublicAnims() {
  const letters = $$(".hero-title span");
  letters.forEach(l => { l.style.opacity = "0"; l.style.transform = "translateY(60px) rotate(4deg)"; });
  an(letters, {
    opacity: [0, 1], translateY: [60, 0], rotate: [4, 0],
    duration: 900, delay: stg ? stg(45) : (el, i) => i * 45, ease: "outExpo"
  });
  an(".hero-badge", { opacity: [0, 1], translateY: [-10, 0], duration: 700, ease: "outCubic" });
  an(".hero-sub, .hero-cta, .hero-stats", { opacity: [0, 1], translateY: [26, 0], duration: 850, delay: stg ? stg(120) : (el, i) => i * 120, ease: "outExpo" });
  an(".glow", { opacity: [0, 0.6], duration: 1600, ease: "outQuad" });
  const sEl = $("#stat-sites");
  if (sEl) countUp(sEl, allSites().length);

  /* scroll reveals */
  const obs = new IntersectionObserver(entries => {
    entries.forEach(en => {
      if (en.isIntersecting) {
        const els = $$(".rv", en.target).length ? [en.target] : [];
        (els.length ? els : [en.target]).forEach(el => el.classList.add("rv-in"));
        obs.unobserve(en.target);
      }
    });
  }, { threshold: 0.12 });
  $$(".rv").forEach((el, i) => { el.style.transitionDelay = (i % 3) * 90 + "ms"; obs.observe(el); });
  safetyShow();
}

/* ================= auth view ================= */
function AuthView() {
  const isLogin = authTab === "login";
  return (
  '<main class="auth-page">' +
    '<div class="dots" aria-hidden="true"></div>' +
    '<div class="auth-glow" aria-hidden="true"></div>' +
    '<div class="auth-box">' +
      '<div style="text-align:center" class="a-h">' +
        '<button class="back-link" onclick="A.go(\'public\')">← Back to UNFOTABLE</button>' +
        '<h1 class="auth-title serif">' + (isLogin ? "Welcome back" : "Claim your ID") + "</h1>" +
        '<p class="auth-sub">' + (isLogin
          ? "Sign in with your UNFO ID and password to open the network."
          : "Every ID is free. 8+ letters and digits — pick it once, keep it forever.") + "</p>" +
      "</div>" +
      '<div class="card auth-card a-rise">' +
        '<div class="tabbar" role="tablist">' +
          '<button class="tab ' + (isLogin ? "active" : "") + '" onclick="A.authMode(\'login\')">Sign in</button>' +
          '<button class="tab ' + (isLogin ? "" : "active") + '" onclick="A.authMode(\'register\')">Create ID</button>' +
        "</div>" +
        '<form style="margin-top:20px" onsubmit="return A.submitAuth(event)">' +
          '<div class="field">' +
            '<label class="label" for="f-id">UNFO ID</label>' +
            '<input class="input" id="f-id" autocomplete="username" placeholder="e.g. Stellar2026" maxlength="24" />' +
            (isLogin ? "" : '<div class="hint">8–24 characters · letters and digits only</div>') +
          "</div>" +
          '<div class="field">' +
            '<label class="label" for="f-pw">Password</label>' +
            '<input class="input" id="f-pw" type="password" autocomplete="' + (isLogin ? "current-password" : "new-password") + '" placeholder="Your password" />' +
            (isLogin ? "" : '<div class="hint">At least 6 characters — you will need it to sign back in.</div>') +
          "</div>" +
          '<button class="btn btn-primary" type="submit" style="width:100%;height:46px;margin-top:6px">' +
            (isLogin ? "Enter the network" : "Create my ID") +
          "</button>" +
        "</form>" +
        '<div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--border);text-align:center;font-size:13px;color:var(--muted)">' +
          (isLogin
            ? 'No ID yet? <button style="font-weight:600;color:#000" onclick="A.authMode(\'register\')">Create one in ten seconds</button>'
            : 'Already have an ID? <button style="font-weight:600;color:#000" onclick="A.authMode(\'login\')">Sign in instead</button>') +
        "</div>" +
      "</div>" +
      '<p style="text-align:center;margin-top:18px;font-size:13px;color:var(--muted)">Your ID works across every website in the UNFOTABLE group.</p>' +
    "</div>" +
  "</main>"
  );
}

function runAuthAnims() {
  an(".auth-page .a-h", { opacity: [0, 1], translateY: [-8, 0], duration: 600, ease: "outCubic" });
  an(".auth-page .a-rise", { opacity: [0, 1], translateY: [26, 0], duration: 800, delay: 120, ease: "outExpo" });
  safetyShow();
}

/*__APP_B__*/
})();
