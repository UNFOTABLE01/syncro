# UNFOTABLE — standalone site (multi-file)

One ID. Many worlds. A self-contained static website hub — no server, no database.
All data (IDs, password hashes, websites, messages) lives in each visitor's browser
localStorage; nothing ever leaves their machine.

## Files

| File         | Purpose                                            |
|--------------|----------------------------------------------------|
| index.html   | Markup + loads everything below                    |
| style.css    | Full stylesheet (cream/black Anthropic-style theme)|
| app.js       | All application logic (views, auth, owner console) |
| anime.min.js | anime.js v4, stored locally — works offline        |

## Run it

- **Locally:** double-click `index.html`. That's it.
- **Host it:** upload the whole folder as-is to any static host —
  Netlify (drag & drop), Cloudflare Pages, GitHub Pages, Vercel, nginx…
  Keep the four files side by side.

## How IDs work

- Every ID is **free** — pick 8–24 letters/digits + a password, and it is yours.
- Nothing is pre-registered. The network ships with a single website:
  **Splid → https://splid.unfo.workers.dev/**
- The ID **Devanshu** (any letter case) automatically carries **full owner
  access**: see every ID, remove IDs, message any member, broadcast, curate
  the website grid, full portfolio.
- Each browser has its own member list — a fresh browser starts empty again.
  Clearing site data resets the network to its original state.

Rebuild from source: `python3 scripts/build_site_folder.py`
