"use client";

import { useEffect, useRef, useState } from "react";
import { Fingerprint, KeyRound, Loader2, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { getAnime } from "./anime";
import type { Me } from "./types";

export function AuthView({
  initialTab,
  onAuthed,
  onBack,
}: {
  initialTab: "login" | "register";
  onAuthed: (me: Me) => void;
  onBack: () => void;
}) {
  const [tab, setTab] = useState<"login" | "register">(initialTab);
  const [id, setId] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const root = cardRef.current;
    if (!root) return;
    let cancelled = false;
    getAnime()
      .then(({ animate, stagger }) => {
        if (cancelled) return;
        animate(root.querySelectorAll(".auth-in"), {
          opacity: [0, 1],
          translateY: [22, 0],
          duration: 750,
          delay: stagger(90),
          ease: "outCubic",
        });
      })
      .catch(() => {
        root.querySelectorAll<HTMLElement>(".auth-in").forEach((el) => {
          el.style.opacity = "1";
          el.style.transform = "none";
        });
      });
    return () => {
      cancelled = true;
    };
  }, []);

  function switchTab(t: "login" | "register") {
    setTab(t);
    setError("");
    setPassword("");
    setConfirm("");
  }

  const idValid = /^[A-Za-z0-9]{8,24}$/.test(id.trim());

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    const trimmed = id.trim();
    if (!/^[A-Za-z0-9]{8,24}$/.test(trimmed)) {
      setError("Your ID needs 8–24 characters — letters and digits only.");
      return;
    }
    if (password.length < 4) {
      setError("Your password needs at least 4 characters.");
      return;
    }
    if (tab === "register" && password !== confirm) {
      setError("The two passwords do not match.");
      return;
    }

    setBusy(true);
    try {
      const res = await fetch(tab === "login" ? "/api/auth/login" : "/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: trimmed, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data?.error || "Something went wrong. Try again.");
        setBusy(false);
        return;
      }
      onAuthed(data.user as Me);
    } catch {
      setError("Network hiccup — try again.");
      setBusy(false);
    }
  }

  return (
    <main className="relative min-h-screen overflow-hidden pt-28 pb-20">
      <div aria-hidden className="unfo-dots absolute inset-0" />
      <div
        aria-hidden
        className="absolute left-1/2 top-0 h-[420px] w-[420px] -translate-x-1/2 rounded-full opacity-50 blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(0,0,0,0.10) 0%, rgba(0,0,0,0.06) 45%, transparent 70%)" }}
      />

      <div ref={cardRef} className="relative mx-auto w-full max-w-md px-4">
        <div className="auth-in text-center">
          <button
            onClick={onBack}
            className="text-xs font-medium uppercase tracking-widest text-muted-foreground transition-colors hover:text-primary"
          >
            ← Back to UNFOTABLE
          </button>
          <h1 className="mt-4 font-display text-3xl font-semibold tracking-tight">
            {tab === "login" ? "Welcome back" : "Claim your ID"}
          </h1>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            {tab === "login"
              ? "Sign in with your UNFO ID and password to open the network."
              : "Every ID is free. 8+ letters and digits — pick it once, keep it forever."}
          </p>
        </div>

        <div className="auth-in mt-8 rounded-3xl border bg-card p-6 sm:p-8 shadow-[0_24px_60px_-30px_rgba(31,30,26,0.35)]">
          {/* tabs */}
          <div className="grid grid-cols-2 rounded-full bg-secondary p-1" role="tablist" aria-label="Authentication mode">
            {(["login", "register"] as const).map((t) => (
              <button
                key={t}
                role="tab"
                aria-selected={tab === t}
                onClick={() => switchTab(t)}
                className={`rounded-full py-2 text-sm font-medium transition-all duration-300 ${
                  tab === t ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t === "login" ? "Sign in" : "Create ID"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="mt-6 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="unfo-id" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                UNFO ID
              </Label>
              <div className="relative">
                <Fingerprint className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="unfo-id"
                  value={id}
                  onChange={(e) => setId(e.target.value)}
                  placeholder="e.g. Stellar2026"
                  autoComplete={tab === "login" ? "username" : "off"}
                  autoCapitalize="none"
                  spellCheck={false}
                  className="h-12 rounded-xl pl-10 text-[15px]"
                />
              </div>
              {tab === "register" && id.length > 0 && !idValid && (
                <p className="text-xs text-destructive/90">
                  8–24 characters · letters & digits only
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="unfo-pass" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                Password
              </Label>
              <div className="relative">
                <KeyRound className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  id="unfo-pass"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={tab === "login" ? "Your password" : "At least 4 characters"}
                  autoComplete={tab === "login" ? "current-password" : "new-password"}
                  className="h-12 rounded-xl pl-10 text-[15px]"
                />
              </div>
            </div>

            {tab === "register" && (
              <div className="space-y-1.5">
                <Label htmlFor="unfo-pass2" className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                  Repeat password
                </Label>
                <div className="relative">
                  <ShieldCheck className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="unfo-pass2"
                    type="password"
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    placeholder="Same password again"
                    autoComplete="new-password"
                    className="h-12 rounded-xl pl-10 text-[15px]"
                  />
                </div>
              </div>
            )}

            {error && (
              <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </p>
            )}

            <Button
              type="submit"
              disabled={busy}
              className="h-12 w-full rounded-xl text-[15px] font-medium transition-transform hover:scale-[1.01] active:scale-[0.99]"
            >
              {busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {tab === "login" ? "Enter the network" : "Create my ID"}
            </Button>
          </form>

          <Separator className="my-6" />
          <p className="text-center text-xs leading-relaxed text-muted-foreground">
            {tab === "login" ? (
              <>
                No ID yet?{" "}
                <button onClick={() => switchTab("register")} className="font-medium text-primary hover:underline">
                  Create one in ten seconds
                </button>
              </>
            ) : (
              <>
                Already have one?{" "}
                <button onClick={() => switchTab("login")} className="font-medium text-primary hover:underline">
                  Sign in instead
                </button>
              </>
            )}
          </p>
        </div>

        <p className="auth-in mt-6 text-center text-xs leading-relaxed text-muted-foreground">
          Your ID works across every website in the UNFOTABLE group.
        </p>
      </div>
    </main>
  );
}
